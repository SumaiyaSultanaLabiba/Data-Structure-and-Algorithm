#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int n, m; //n= number of nodes, m=number of edges
    cin>>n>>m;
    vector<pair<int, int>> edges(m+1);
    vector<long int> cost(m+1);

    for(int i=1; i<=m; i++)
    {
        int u, v, c;
        cin>>u>>v>>c;
        edges[i].first=u, edges[i].second=v;
        cost[i]=c;
    }

    //Bellman-Ford 
    vector<long int> first_distance(n+1, 0);
    vector<long int> second_distance(n+1, 0);
    vector<int> parent(n+1, 0);

    for(int i=1; i<=n-1; i++)
    {
        for(int k=1; k<=n; k++) second_distance[k]=first_distance[k];
          for(int j=1; j<=m; j++)
          {
              int u=edges[j].first, v=edges[j].second; 
              if(first_distance[u]+cost[j]<second_distance[v]) 
              {
                    second_distance[v]=first_distance[u]+cost[j];
                    parent[v]=u;
              }
          }
        for(int k=1; k<=n; k++) first_distance[k]=second_distance[k];
    }

    //negative cycle detection
    bool isNegative=false;
    int w;// Node 'w' is reachable from any negative cycle, or the node itself is on that negative cycle
    for(int k=1; k<=n; k++) second_distance[k]=first_distance[k];
    for(int j=1; j<=m; j++)
    {
        int u=edges[j].first, v=edges[j].second; 
        if(first_distance[u]+cost[j]<first_distance[v])
        {
            isNegative=true;
            w=v;
            parent[v]=u;
        }
    }

    //negative cycle printing
    if(isNegative)
    {
        for(int i=0; i<n; i++) w=parent[w];
        vector<int> cycle;
        int current=w;
        bool first_iteration=true;
        while(true)
        {
            cycle.push_back(current);
            if (current==w && !first_iteration) break;
            current=parent[current];
            first_iteration=false;
        }

        int nodes_on_cycle=cycle.size();
        for(int i=nodes_on_cycle-1; i>0; i--)
        {
            cout<<cycle[i]<<" ";
        }
    }

    else cout<<-1;

    return 0;
}