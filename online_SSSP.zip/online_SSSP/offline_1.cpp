#include<iostream>
#include<bits/stdc++.h>
using namespace std;

const long long int INF=1e18;


void swap_pairs(vector<pair<long int, long int>>& edges)
{
    long int length=edges.size();
    for(int i=0; i<length; i++)
    {
        long int temp=edges[i].first;
        edges[i].first=edges[i].second;
        edges[i].second=temp;
    }
}


void Dijkstra(vector<pair<long int, long int>>& edges, vector<long long int>& cost, vector<long long int>& minimum_cost, long int start)
{
    long int num_of_nodes=minimum_cost.size()-1;
    long int num_of_edges=edges.size()-1;

    //building adjacency list
    vector<vector<pair<long int, long long int>>> adjList(num_of_nodes+1);
    for(long int i=1; i<=num_of_edges; i++)
    {
        long int u=edges[i].first;
        long int v=edges[i].second;
        adjList[u].push_back({v, cost[i]});
    }

    priority_queue<pair<long int, long long int>, vector<pair<long int, long long int>>,greater<pair<long int, long long int>>> pq;
    minimum_cost[start]=0;
    pq.push({minimum_cost[start], start});

    while(!pq.empty())
    {
        pair<long int, long long int> top=pq.top();
        pq.pop();

        long int node=top.second;
        long long int distance=top.first;

        if(distance>minimum_cost[node]) continue;

        long int num=adjList[node].size();
        for(long int i=0; i<num; i++)
        {
            long int u=node;
            long int v=adjList[node][i].first;
            long long int edge_weight=adjList[node][i].second;

            if(minimum_cost[v]>minimum_cost[u]+edge_weight)
            {
                minimum_cost[v]=minimum_cost[u]+edge_weight;
                pq.push({minimum_cost[v], v});
            }
        }
    }
}


int main()
{
    long int n, m; //n= number of airports, m= number of flight connections
    cin>>n>>m;
    vector<pair<long int, long int>> edges(m+1);
    vector<long long int> cost(m+1);

    for(long int i=1; i<=m; i++)
    {
        long int u, v;
        long long c;
        cin>>u>>v>>c;
        edges[i].first=u, edges[i].second=v;
        cost[i]=c;
    }

    vector<long long int> cost_from_Dhaka(n+1, INF);
    vector<long long int> cost_to_London(n+1, INF);

    Dijkstra(edges, cost, cost_from_Dhaka, 1);
    swap_pairs(edges);
    Dijkstra(edges, cost, cost_to_London, n);
    swap_pairs(edges);

    long long int min_cost= INF;
    for(long int i=1; i<=m; i++)
    {
       long int u=edges[i].first;
       long int v=edges[i].second;
       long long int total_cost=cost_from_Dhaka[u]+cost[i]/2+cost_to_London[v];

       if(total_cost<min_cost) min_cost=total_cost;
    }

    cout<<min_cost<<endl;
    return 0;
}