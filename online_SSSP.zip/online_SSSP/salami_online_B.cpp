#include<iostream>
#include<bits/stdc++.h>
using namespace std;


const int INF=100000;
bool is_neg_cycle_present=false;

int main()
{
    int n, m, k, b, e;
    cin>>n>>m>>k>>b>>e;

    set<int> capitals;
    for(int i=1; i<=k; i++)
    {
        int z;
        cin>>z;
        capitals.insert(z);
    }

    set<int> blocked;
    for(int i=1; i<=b; i++)
    {
        int z;
        cin>>z;
        blocked.insert(z);
    }

    set<int> emergency;
    for(int i=1; i<=e; i++)
    {
        int z;
        cin>>z;
        emergency.insert(z);
    }

    vector<vector<pair<int, int>>> adjList(n+1);

    for(int i=1; i<=m; i++)
    {
        int u, v, w;
        cin>>u>>v>>w;
        if(blocked.find(u)==blocked.end() && blocked.find(v)==blocked.end())
        {
        adjList[u].push_back({v,w});
        }
    }

    //starting Bellman-Ford
    vector<int> first_dist(n+1, INF);
    vector<int> second_dist(n+1, INF);
    for(int c: capitals)
    {
      first_dist[c]=0;
      second_dist[c]=0;
    }

    for(int i=1; i<=n-1; i++)
    {
        for(int u=1; u<=n; u++)
        {
            for(pair<int, int> p : adjList[u])
            {
                int v=p.first, w=p.second;
                if(first_dist[u]!=INF && first_dist[u]+w < first_dist[v])
                {
                    second_dist[v]=first_dist[u]+w;
                }
            }
        }
        for(int k=1; k<=n; k++) first_dist[k]=second_dist[k];
    }


    //checking if there is any negative cycle
    for(int u=1; u<=n; u++)
    {
        for(pair<int, int> p : adjList[u])
        {
            int v=p.first, w=p.second;
            if(first_dist[u]!=INF && first_dist[u]+w < first_dist[v])
            {
                second_dist[v]=first_dist[u]+w;
            }
        }
    }
    bool is_neg_cycle_present=false;
    int reachable_node_from_neg_cycle=-1;
    for(int i=1; i<=n; i++)
    {
        if(first_dist[i]!= second_dist[i])
        {
            is_neg_cycle_present=true;
            reachable_node_from_neg_cycle=i;
            break;
        }
    }

    //if no negative cycle, print the shortest distances for each node. Otherwise, print the negative cycle
    if(!is_neg_cycle_present)
    {
        for(int e: emergency)
        {
            cout<<first_dist[e]<<endl;
        }
    }
    
    else
    {
      cout<<"Abyss detected!!"<<endl;
    }
    
    
    return 0;
}