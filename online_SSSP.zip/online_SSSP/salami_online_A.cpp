#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int K, N, X; 
    cin>>K>>N>>X;
    vector<vector<pair<int, int>>> adjList(N+1);

    for(int i=1; i<=X; i++)
    {
        int u, v, t, c;
        cin>>u>>v>>t>>c;
        int w = c+K*(t+1);
        adjList[u].push_back({v,w});
        adjList[v].push_back({u,w});
    }

    //starting Dijkstra
    int S;
    cin>>S;
    priority_queue<pair<int,int>, vector<pair<int, int>>, greater<pair<int,int>>> not_sure;// stores (distance, node) pairs
    vector<int> shortest_distance(N+1, INT_MAX);
    vector<int> parent(N+1, -1);
    parent[S]=-1;
    vector<bool> sure(N+1, false);
    shortest_distance[S]=0;
    not_sure.push({0, S});

    while(!not_sure.empty())
    {
        int current_dist=not_sure.top().first;
        int current_node=not_sure.top().second;
        not_sure.pop();
        for(pair<int,int> p: adjList[current_node])
        {
            int v=p.first, w=p.second;
            if(!sure[v] && shortest_distance[v]>shortest_distance[current_node]+w)
            {
                shortest_distance[v]=shortest_distance[current_node]+w;
                parent[v]=current_node;
                not_sure.push({shortest_distance[v], v});
            }
        }
        sure[current_node]=true;
    }

    for(int i=1; i<=N; i++)
    {
        if(i==S) continue;
        shortest_distance[i]=shortest_distance[i]-K;
    }
    int D;
    cin>>D;
    vector<int> path;
    path.push_back(D);
    int par=parent[D];
    while(par!=-1)
    {
        path.push_back(par);
        par=parent[par];
    }
    for(int i=path.size()-1; i>=0; i--)
    {
        cout<<path[i]<<' ';
    }
    cout<<endl;
    cout<<shortest_distance[D]<<endl;
    return 0;
}