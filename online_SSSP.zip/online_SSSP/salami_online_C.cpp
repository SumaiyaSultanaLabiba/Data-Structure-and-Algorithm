#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int n, m, f; // n= number of labs, m= number of roads, f = fixed entry fee for any lab
    cin>>n>>m>>f;
    vector<int> capacity(n+1, 0);
    for(int i=1; i<=n; i++)
    {
        cin>>capacity[i];
    }

    vector<vector<pair<int, int>>> adjList(n+1);

    for(int i=1; i<=m; i++)
    {
        int u, v, w;// an edge (u,v) with a weight w.
        cin>>u>>v>>w;
        adjList[u].push_back({v,w});
        adjList[v].push_back({u,w});
    }

    int k; // k = number of students
    cin>>k;

    //starting Dijkstra
    int root=1;
    priority_queue<pair<int,int>, vector<pair<int, int>>, greater<pair<int,int>>> not_sure;// stores (distance, node) pairs
    vector<int> shortest_distance(n+1, INT_MAX);
    vector<bool> sure(n+1, false);
    shortest_distance[root]=0;
    not_sure.push({0, root});

    while(!not_sure.empty())
    {
        int current_dist=not_sure.top().first;
        int current_node=not_sure.top().second;
        not_sure.pop();
        for(pair<int,int> p: adjList[current_node])
        {
            int v=p.first, w=p.second;
            if(!sure[v] && shortest_distance[v]>shortest_distance[current_node]+w)
            {
                shortest_distance[v]=shortest_distance[current_node]+w;
                not_sure.push({shortest_distance[v], v});
            }
        }
        sure[current_node]=true;
    }


    //find order among different labs to push students
    vector<int> order_of_labs(n+1, INT_MAX);
    vector<bool> visited(n+1, false);
    for(int i=1; i<=n; i++)
    {
        int best_lab=-1;
        int best_cost=INT_MAX;
        for(int j=1; j<=n; j++)
        {
           if(shortest_distance[j]<best_cost && visited[j]==false)
           {
              best_cost=shortest_distance[j];
              best_lab=j;
           }
        }
        order_of_labs[i]=best_lab;
        visited[best_lab]=true;
    }


   

    vector<int> lab_allocation(k+1, -1);
    int p=1;
    int current_lab=order_of_labs[p];
    for(int i=1; i<=k; i++)
    {
       if(capacity[current_lab]>0)
       {
          lab_allocation[i]=current_lab;
          capacity[current_lab]--;
       }
       else
       {
          p++;
          if(p>n) lab_allocation[i]=-1;
          else
          {
            current_lab=order_of_labs[p];
            lab_allocation[i]=current_lab;
            capacity[current_lab]--;
          }
       }
    }

    

    
    for(int i=1; i<=k; i++)
    {
        int allocated_lab=lab_allocation[i];
        if(allocated_lab==-1) cout<<allocated_lab<< ' ';
        else cout<<shortest_distance[allocated_lab]+f<< ' ';
    }

    cout<<endl;

    return 0;
}