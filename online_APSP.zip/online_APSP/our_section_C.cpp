#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int n, m; // n= number of nodes, m= number of edges
    cin>>n>>m;
    vector<vector<pair<int, int>>> adjList(n);
    vector<vector<pair<int, int>>> adjList_less(n);

    for(int i=0; i<m; i++)
    {
        int u, v, w;// an edge (u,v) with a weight w.
        cin>>u>>v>>w;
        adjList[u].push_back({v,w});
        adjList_less[u].push_back({v,w-1});
        //adjList[v].push_back({u,w});
    }

    int discount_city;
    cin>>discount_city;

    int num_of_queries;
    cin>>num_of_queries;

    vector<pair<int,int>> queries(num_of_queries);
    for(int i=0; i<num_of_queries; i++)
    {
        int u, v;
        cin>>u>>v;
        queries[i]={u,v};
    }

    //starting Floyd-Warshall
    vector<vector<int>> D(n, vector<int>(n, INT_MAX));// D is a 2-D matrix for storing shortest distances between all (u,v) pairs
    
    for(int i=0; i<n; i++) {D[i][i]=0;}
    
    for(int u=0; u<n; u++)
    {
        for(int j=0; j<adjList[u].size(); j++)
        {
           int v=adjList[u][j].first;
           int w=adjList[u][j].second;
           if(w<D[u][v]) //if there are multiple edges from u->v, take the edge with minimum weight
           {
              D[u][v]=w;
           }
        }
    }

    for(int count=0; count<n; count++)
    {
       for(int i=0; i<n; i++)
       {
          for(int j=0; j<n; j++)
          {
            if(D[i][count]!=INT_MAX && D[count][j]!=INT_MAX)
            {
                if(D[i][count]+D[count][j] < D[i][j])
                {
                    D[i][j]= D[i][count]+D[count][j];
                }
            }
          }
       }
    }


    //second time Floyd-Warshall
    vector<vector<int>> D_less(n, vector<int>(n, INT_MAX));
    for(int i=0; i<n; i++) {D_less[i][i]=0;}
    
    for(int u=0; u<n; u++)
    {
        for(int j=0; j<adjList_less[u].size(); j++)
        {
           int v=adjList_less[u][j].first;
           int w=adjList_less[u][j].second;
           if(w<D_less[u][v]) //if there are multiple edges from u->v, take the edge with minimum weight
           {
              D_less[u][v]=w;
           }
        }
    }

    for(int count=0; count<n; count++)
    {
       for(int i=0; i<n; i++)
       {
          for(int j=0; j<n; j++)
          {
            if(D_less[i][count]!=INT_MAX && D_less[count][j]!=INT_MAX)
            {
                if(D_less[i][count]+D_less[count][j] < D_less[i][j])
                {
                    D_less[i][j]= D_less[i][count]+D_less[count][j];
                }
            }
          }
       }
    }


   //result
   vector<vector<int>> D_final(n, vector<int>(n, INT_MAX));
   for(int u=0; u<n; u++)
   {
    for(int v=0; v<n; v++)
    {
        if(D[u][v]<D_less[u][discount_city]+D_less[discount_city][v]) D_final[u][v]=D[u][v];
        else D_final[u][v]=D_less[u][discount_city]+D_less[discount_city][v];
    }
   }

   for(int i=0; i<num_of_queries; i++)
   {
     if(D_final[queries[i].first][queries[i].second]==INT_MAX) cout<<-1<<endl;
     else cout<<D_final[queries[i].first][queries[i].second]<<endl;
   }
    return 0;
}