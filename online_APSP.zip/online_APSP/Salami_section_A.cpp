#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int N, M, K, X; // N= number of cities, M= number of roads, K= number of lords, X= hours remaining before meeting
    cin>>N>>M>>K>>X;

    vector<int> current_cities(K+1, 0);
    for(int i=1; i<=K; i++)
    {
        cin>>current_cities[i];
    }

    vector<int> hourly_rate(K+1, 0);
    for(int i=1; i<=K; i++)
    {
        cin>>hourly_rate[i];
    }

    vector<vector<pair<int, int>>> adjList(N+1);
    for(int i=1; i<=M; i++)
    {
        int u, v, t;// a road (u,v) with a travel time t.
        cin>>u>>v>>t;
        adjList[u].push_back({v,t});
        //adjList[v].push_back({u,t});
    }


    //starting Floyd-Warshall
    vector<vector<int>> D(N+1, vector<int>(N+1, INT_MAX));// D is a 2-D matrix for storing shortest distances between all (u,v) pairs
    vector<vector<int>> next(N+1, vector<int>(N+1, -1));// next is a 2D matrix where each cell (u,v) keeps the next node of u in the shortest path of u->v

    for(int i=1; i<=N; i++) {D[i][i]=0; next[i][i]=i;}
    
    for(int u=1; u<=N; u++)
    {
        for(int j=0; j<adjList[u].size(); j++)
        {
           int v=adjList[u][j].first;
           int w=adjList[u][j].second;
           if(w<D[u][v]) //if there are multiple roads from u->v, take the edge with minimum travel time
           {
              D[u][v]=w;
              next[u][v]=v;
           }
        }
    }

    for(int count=1; count<=N; count++)
    {
       for(int i=1; i<=N; i++)
       {
          for(int j=1; j<=N; j++)
          {
            if(D[i][count]!=INT_MAX && D[count][j]!=INT_MAX)
            {
                if(D[i][count]+D[count][j] < D[i][j])
                {
                    D[i][j]= D[i][count]+D[count][j];
                    next[i][j]=next[i][count];
                }
            }
          }
       }
    }

    vector<bool> eligible_cities(N+1, true);// a checking array for all cities whether it can be reached within X time by all lords
    for(int i=1; i<=K; i++)
    {
        int current_city=current_cities[i];
        for(int j=1; j<=N; j++)
        {
            if(D[current_city][j]<=X) eligible_cities[j]= eligible_cities[j] && true;
            else eligible_cities[j]= eligible_cities[j] && false;
            //or, another approach: 
            //if(D[current_city][j]>X) eligible_cities[j]= false;
        }
    }

    vector<pair<int,int>> chosen_cities;//the cities where all lords can reach within X time, paired in (city, total_cost_to_reach_there) format

    for(int i=1; i<=N; i++)
    {
        if(eligible_cities[i])
        {
            int total_cost=0;
            for(int j=1; j<=K; j++)
            {
                total_cost+=D[current_cities[j]][i]*hourly_rate[j];
            }
            chosen_cities.push_back({i, total_cost});
        }
    }


    if(chosen_cities.empty())
    {
        cout<<"No meeting"<<endl;
    }

    else
    {
        pair<int, int> meeting_city_totalcost_pair=chosen_cities[0];
        for(int i=1; i<chosen_cities.size(); i++)
        {
            if(chosen_cities[i].second<meeting_city_totalcost_pair.second)
            {
                meeting_city_totalcost_pair=chosen_cities[i];
            }
        }

        int max_time=0;
        for(int i=1; i<=K; i++)
        {
            if(D[current_cities[i]][meeting_city_totalcost_pair.first]>max_time)
            {
                max_time=D[current_cities[i]][meeting_city_totalcost_pair.first];
            }
        }
        cout<<meeting_city_totalcost_pair.first<<" "<<meeting_city_totalcost_pair.second<<" "<<max_time<<endl;

        for(int i=1; i<=K; i++)
        {
            int current_city=current_cities[i];
            int current=current_city;
            int destination=meeting_city_totalcost_pair.first;
            int n=next[current][destination];
            vector<int> path;
            path.push_back(current);
            while(n!=destination)
            {
                path.push_back(n);
                n=next[n][destination];
                current=next[current][destination];
            }
            path.push_back(destination);
            for(int c=0; c<path.size(); c++)
            {
                if(c==path.size()-1) cout<<path[c];
                else cout<<path[c]<<"->";
            }
            cout<<" ";
            cout<<D[current_city][destination]*hourly_rate[i]<<endl;
        }
    }
    return 0;
}