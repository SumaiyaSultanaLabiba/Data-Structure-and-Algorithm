#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int N, M, K; // N= number of armies, m= number of roads, K= number of maximum groups per batch
    cin>>N>>M>>K;
    vector<int> current_station(N+1, -1);
    for(int i=1; i<=N; i++)
    {
        cin>>current_station[i];
    }

    vector<int> target_station(N+1, -1);
    for(int i=1; i<=N; i++)
    {
        cin>>target_station[i];
    }
    vector<vector<pair<int, int>>> adjList(N+1);

    for(int i=1; i<=M; i++)
    {
        int u, v, w;
        cin>>u>>v>>w;
        adjList[u].push_back({v,w});
    }


    //starting Floyd-Warshall
    vector<vector<int>> D(N+1, vector<int>(N+1, INT_MAX));// D is a 2-D matrix for storing shortest distances between all (u,v) pairs
    vector<vector<int>> next(N+1, vector<int>(N+1, -1));// next is a 2D matrix which each cell (u,v) the next node of u in the shortest path of u->v

    for(int i=1; i<=N; i++) {D[i][i]=0; next[i][i]=i;}
    
    for(int u=1; u<=N; u++)
    {
        for(int j=0; j<adjList[u].size(); j++)
        {
           int v=adjList[u][j].first;
           int w=adjList[u][j].second;
           if(w<D[u][v]) //if there are multiple edges from u->v, take the edge with minimum weight
           {
              D[u][v]=w;
              next[u][v]=v;
           }
        }
    }

    for(int count=1; count<=N; count++)
    {
       for(int i=1; i<=N; i++)
       {
          for(int j=1; j<=N; j++)
          {
            if(D[i][count]!=INT_MAX && D[count][j]!=INT_MAX)
            {
                if(D[i][count]+D[count][j] < D[i][j])
                {
                    D[i][j]= D[i][count]+D[count][j];
                    next[i][j]=next[i][count];
                }
            }
          }
       }
    }

    priority_queue<pair<int,int>, vector<pair<int, int>>> pq;// stores {cost, army_id} in descending order
    for(int i=1; i<=N; i++)
    {
        pq.push({D[current_station[i]][target_station[i]], i});
    }

    vector<int> ordering(N+1, -1);
    for(int i=1; i<=N; i++)
    {
       pair<int, int> temp=pq.top();
       pq.pop();
       ordering[i]=temp.second;
    }

    int total_cost=0;
    int index=1;
    int factor=1;
    while(index<=N)
    {
       int army_id=ordering[index]; 
       if(D[current_station[army_id]][target_station[army_id]]==INT_MAX) 
       {
         index++;
         continue;
       }
       total_cost+= D[current_station[army_id]][target_station[army_id]]*factor;
       if(index%K==0) factor*=2;
       index++;
    }

    cout<<total_cost<<endl;
    return 0;
}