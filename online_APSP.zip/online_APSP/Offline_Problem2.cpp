#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int n;// n= number of different currencies
    cin>>n;

    map<string, int> currency;//maps currency names to integer nodes
    for(int i=1; i<=n; i++)
    {
       string name;
       cin>>name;
       currency.insert({name, i});
    }

    vector<vector<pair<int, float>>> adjList(n+1);
    int m; //number of possible conversions between different currencies
    cin>>m;
    for(int i=1; i<=m; i++)
    {
        float w;
        string s, t; // s->t conversion factor is w
        cin>>s;
        cin>>w;
        cin>>t;
        int u, v; 
        u=currency[s], v=currency[t];
        adjList[u].push_back({v,w});
    }


    //******starting Floyd-Warshall******
    vector<vector<float>> D(n+1, vector<float>(n+1, 0.0));// D is a 2-D matrix for storing the conversion factor for each currency pair
    
    //initialization
    for(int i=1; i<=n; i++) {D[i][i]=1.0;}
    
    for(int u=1; u<=n; u++)
    {
        for(int j=0; j<adjList[u].size(); j++)
        {
           int v=adjList[u][j].first;
           float w=adjList[u][j].second;
           if(w>D[u][v]) //if there are multiple direct conversion ways from u->v, the way with maximum factor should be taken
           {
              D[u][v]=w;
           }
        }
    }

    //iterations
    for(int count=1; count<=n; count++)
    {
       for(int i=1; i<=n; i++)
       {
          for(int j=1; j<=n; j++)
          {
            if(D[i][count]*D[count][j] > D[i][j])
            {
                D[i][j]= D[i][count]*D[count][j];
            }
          }
       }
    }

    //checking for arbitrage
    bool arbitrage_possible=false;
    for(int i=1; i<=n; i++)
    {
        if(D[i][i]>1)
        {
            arbitrage_possible=true;
            break;
        }    
    }

    if(arbitrage_possible) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
    
    return 0;
}