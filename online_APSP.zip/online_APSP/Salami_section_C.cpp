#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int n, m, k; // n= number of labs, m= number of roads, k= number of students
    cin>>n>>m>>k;

    vector<int> capacity(n+1, -1);
    for(int i=1; i<=n; i++)
    {
        cin>>capacity[i];
    }
    vector<vector<pair<int, int>>> adjList(n+1);

    for(int i=1; i<=m; i++)
    {
        int u, v, w;// an edge (u,v) with a weight w.
        cin>>u>>v>>w;
        if(capacity[u]==-1 || capacity[v]==-1) continue;
        adjList[u].push_back({v,w});
        adjList[v].push_back({u,w});
    }

    int q;
    cin>>q;
    vector<int> queries(q+1, -1);
    for(int i=1; i<=q; i++)
    {
        cin>>queries[i];
    }


    //starting Floyd-Warshall
    vector<vector<int>> D(n+1, vector<int>(n+1, INT_MAX));// D is a 2-D matrix for storing shortest distances between all (u,v) pairs
    vector<vector<int>> next(n+1, vector<int>(n+1, -1));// next is a 2D matrix which each cell (u,v) the next node of u in the shortest path of u->v

    for(int i=1; i<=n; i++) {D[i][i]=0; next[i][i]=i;}
    
    for(int u=1; u<=n; u++)
    {
        for(int j=0; j<adjList[u].size(); j++)
        {
           int v=adjList[u][j].first;
           int w=adjList[u][j].second;
           if(w<D[u][v]) //if there are multiple edges from u->v, take the edge with minimum weight
           {
              D[u][v]=w;
              next[u][v]=v;
           }
        }
    }

    for(int count=1; count<=n; count++)
    {
       for(int i=1; i<=n; i++)
       {
          for(int j=1; j<=n; j++)
          {
            if(D[i][count]!=INT_MAX && D[count][j]!=INT_MAX)
            {
                if(D[i][count]+D[count][j] < D[i][j])
                {
                    D[i][j]= D[i][count]+D[count][j];
                    next[i][j]=next[i][count];
                }
            }
          }
       }
    }

    for(int i=1; i<=q; i++)
    {
        int source=queries[i];
        vector<int> capacity_use(n+1, -1);
        for(int j=1; j<=n; j++)
        {
           capacity_use[j]=capacity[j];
        }
        vector<int> destination(k+1, -1);
        vector<int> first;
        vector<bool> visited(n+1, false);
        for(int j=1; j<=n; j++)
        {
            if(D[source][j]==INT_MAX) continue;
            first.push_back(j);
        }
        vector<int> second;
        for(int j=0; j<first.size(); j++)
        {
           int min_dist=INT_MAX;
           int min_node=-1;
           for(int s=0; s<first.size(); s++)
           {
              if(min_dist> D[source][first[s]] && !visited[first[s]])
              {
                min_dist=D[source][first[s]];
                min_node=first[s];
              }
           }
           second.push_back(min_node);
           visited[min_node]=true;
        }

        int student=1;
        for(int j=0; j<second.size(); j++)
        {
            while(student<=k && capacity_use[second[j]]>0)
            {
                destination[student]=second[j];
                capacity_use[second[j]]--;
                student++;
            }
        }

        for(int j=1; j<=k; j++)
        {
            if(destination[j]==-1) cout<<-1<<" ";
            else cout<<D[source][destination[j]]<<" ";
        }
        cout<<endl;
    }

    return 0;
}