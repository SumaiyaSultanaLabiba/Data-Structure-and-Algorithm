#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int n, m, q;// n= number of cities, m= number of roads, q=number of queries
    cin>>n>>m>>q;
    vector<vector<pair<int, int>>> adjList(n+1);

    for(int i=1; i<=m; i++)
    {
        int u, v, w; // a road u->v with a length w.
        cin>>u>>v>>w;
        adjList[u].push_back({v,w});
        adjList[v].push_back({u,w});
    }


    //*******starting Floyd-Warshall********
    vector<vector<int>> D(n+1, vector<int>(n+1, INT_MAX));// D is a 2-D matrix for storing shortest distances between all city pairs
    
    //initialization
    for(int i=1; i<=n; i++) {D[i][i]=0;}
    
    for(int u=1; u<=n; u++)
    {
        for(int j=0; j<adjList[u].size(); j++)
        {
           int v=adjList[u][j].first;
           int w=adjList[u][j].second;
           if(w<D[u][v]) //if there are multiple roads from u->v, the road with minimum length is taken
           {
              D[u][v]=w;
           }
        }
    }

    //iterations
    for(int count=1; count<=n; count++)
    {
       for(int i=1; i<=n; i++)
       {
          for(int j=1; j<=n; j++)
          {
            if(D[i][count]!=INT_MAX && D[count][j]!=INT_MAX)
            {
                if(D[i][count]+D[count][j] < D[i][j])
                {
                    D[i][j]= D[i][count]+D[count][j];
                }
            }
          }
       }
    }

    //processing queries
    for(int i=0; i<q; i++)
    {
        int u, v;
        cin>>u>>v;
        if(D[u][v]==INT_MAX) cout<<-1<<endl;
        else cout<<D[u][v]<<endl;
    }

    return 0;
}