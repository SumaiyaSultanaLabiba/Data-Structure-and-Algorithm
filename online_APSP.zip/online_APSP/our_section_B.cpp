#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main()
{
    int n, m; // n= number of nodes, m= number of edges
    cin>>n>>m;
    vector<vector<pair<int, int>>> adjList(n);

    for(int i=0; i<m; i++)
    {
        int u, v, w;// an edge (u,v) with a weight w.
        cin>>u>>v>>w;
        adjList[u].push_back({v,w});
        //adjList[v].push_back({u,w});
    }

    int mandatory_city1, mandatory_city2;
    cin>>mandatory_city1>>mandatory_city2;
    int number_of_queries;
    cin>>number_of_queries;
    vector<pair<int,int>> queries(number_of_queries);
    for(int i=0; i<number_of_queries; i++)
    {
        int u, v;
        cin>>u>>v;
        queries[i]={u,v};
    }

    //starting Floyd-Warshall
    vector<vector<int>> D(n, vector<int>(n, INT_MAX));// D is a 2-D matrix for storing shortest distances between all (u,v) pairs
    vector<vector<int>> next(n, vector<int>(n, -1));// next is a 2D matrix which each cell (u,v) the next node of u in the shortest path of u->v

    for(int i=0; i<n; i++) {D[i][i]=0; next[i][i]=i;}
    
    for(int u=0; u<n; u++)
    {
        for(int j=0; j<adjList[u].size(); j++)
        {
           int v=adjList[u][j].first;
           int w=adjList[u][j].second;
           if(w<D[u][v]) //if there are multiple edges from u->v, take the edge with minimum weight
           {
              D[u][v]=w;
              next[u][v]=v;
           }
        }
    }

    for(int count=0; count<n; count++)
    {
       for(int i=0; i<n; i++)
       {
          for(int j=0; j<n; j++)
          {
            if(D[i][count]!=INT_MAX && D[count][j]!=INT_MAX)
            {
                if(D[i][count]+D[count][j] < D[i][j])
                {
                    D[i][j]= D[i][count]+D[count][j];
                    next[i][j]=next[i][count];
                }
            }
          }
       }
    }

    vector<int> query_result(number_of_queries);
    for(int i=0; i<number_of_queries; i++)
    {
        int u, v;
        u=queries[i].first, v=queries[i].second;
        
        if(D[u][mandatory_city1]==INT_MAX || D[mandatory_city1][v]==INT_MAX)
        {
            if(D[u][mandatory_city2]==INT_MAX || D[mandatory_city2][v]==INT_MAX)
            {
                query_result[i]=-1;
            }
            else
            {
                query_result[i]=D[u][mandatory_city2] + D[mandatory_city2][v];
            }
        }
        else
        {
            if(D[u][mandatory_city2]==INT_MAX || D[mandatory_city2][v]==INT_MAX)
            {
                query_result[i]=D[u][mandatory_city1] + D[mandatory_city1][v];
            }
            else
            {
                if(D[u][mandatory_city1] + D[mandatory_city1][v]<D[u][mandatory_city2] + D[mandatory_city2][v])
                {
                    query_result[i]=D[u][mandatory_city1] + D[mandatory_city1][v];
                }
                else query_result[i]=D[u][mandatory_city2] + D[mandatory_city2][v];
            }
        }
    }

    for(int i=0; i<number_of_queries; i++)
    {
        cout<<query_result[i]<<endl;
    }

    return 0;
}