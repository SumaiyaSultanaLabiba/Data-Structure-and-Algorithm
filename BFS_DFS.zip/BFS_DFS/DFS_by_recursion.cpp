#include<iostream>
#include<vector>
using namespace std;


void DFS_visit(const vector<vector<int>>& adjList, int root, vector<int>& startTime, vector<int>& finishTime, vector<int>& visited, int& currentTime){
   visited[root]=1;
   cout<<root<<"  ";
   startTime[root]=currentTime++;
   for(int i: adjList[root])
   {
      if(!visited[i]) DFS_visit(adjList, i, startTime, finishTime, visited, currentTime);
   }
   finishTime[root]=currentTime++;
}


void DFS(const vector<vector<int>>& adjList, int n, int root)
{
   vector<int> visited(n+1, 0);
   vector<int> startTime(n+1, 0);
   vector<int> finishTime(n+1, 0);
   
   int currentTime=0;
   DFS_visit(adjList, root, startTime, finishTime, visited, currentTime);
   for(int i=1; i<=n; i++)
   {
      cout<<"Node: "<<i<<", Start: "<<startTime[i]<<", Finish: "<<finishTime[i]<<endl;
   }
}


int main()
{
    int n, m; //n= number of nodes, m=number of edges
    cin>>n>>m;
    vector<vector<int>> adjList(n+1);
    for(int i=0; i<m; i++)
    {
        int u, v;
        cin>>u>>v;
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }
    int root;//root is the starting point of DFS
    cin>>root;
    DFS(adjList, n, root);
    return 0;
}
