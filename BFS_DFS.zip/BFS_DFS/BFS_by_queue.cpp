#include<iostream>
#include<queue>
#include<vector>
using namespace std;


void BFS(const vector<vector<int>>& adjList, int n, int root)
{
   vector<bool> visited(n+1, false);
   vector<int> level(n+1, 0);
   queue<int> q;

   q.push(root);
   visited[root]=true;
   level[root]=0;

   while(!q.empty())
   {
     int currentNode=q.front();
     q.pop();
     cout<<currentNode<<" ";
     for(int i=0; i<adjList[currentNode].size(); i++)
     {
       if(!visited[adjList[currentNode][i]])
       {
        q.push(adjList[currentNode][i]); 
        level[adjList[currentNode][i]]=level[currentNode]+1; 
        visited[currentNode]=true;
       }
     }
   }
   for(int i=1; i<=n; i++)
   {
      cout<<"Node: "<<i<<", Level: "<<level[i]<<endl;
   }
}


int main()
{
    int n, m; //n= number of nodes, m=number of edges
    cin>>n>>m;
    vector<vector<int>> adjList(n+1);
    for(int i=0; i<m; i++)
    {
        int u, v;
        cin>>u>>v;
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }
    int root;//root is the starting point of DFS
    cin>>root;
    BFS(adjList, n, root);
    return 0;
}
