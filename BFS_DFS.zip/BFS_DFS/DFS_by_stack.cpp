#include<iostream>
#include<stack>
#include<vector>
using namespace std;


void DFS(const vector<vector<int>>& adjList, int n, int root)
{
   vector<int> visited(n+1, 0);
   vector<int> startTime(n+1, 0);
   vector<int> finishTime(n+1, 0);
   vector<bool> isFinished(n+1, false);

   int currentTime=0;
   stack<int> s;

   s.push(root);

   while(!s.empty())
   {
    int currentNode=s.top();
    s.pop();
    if(!isFinished[currentNode])
    {
        if(visited[currentNode]) continue;
        visited[currentNode]=1;
        cout<<currentNode<<" ";
        startTime[currentNode]=currentTime++;
        s.push(currentNode);
        isFinished[currentNode]=true;
        for(int i=adjList[currentNode].size()-1; i>=0; i--)
        {
        if(!visited[adjList[currentNode][i]]) s.push(adjList[currentNode][i]);
        }
        if(adjList[currentNode].size()==0) finishTime[currentNode]=currentTime++;
    }
    else
        finishTime[currentNode]=currentTime++;
   }
   for(int i=1; i<=n; i++)
   {
      cout<<"Node: "<<i<<", Start: "<<startTime[i]<<", Finish: "<<finishTime[i]<<endl;
   }
}


int main()
{
    int n, m; //n= number of nodes, m=number of edges
    cin>>n>>m;
    vector<vector<int>> adjList(n+1);
    for(int i=0; i<m; i++)
    {
        int u, v;
        cin>>u>>v;
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }
    int root;//root is the starting point of DFS
    cin>>root;
    DFS(adjList, n, root);
    return 0;
}
