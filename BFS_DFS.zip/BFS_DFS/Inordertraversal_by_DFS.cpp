#include<iostream>
using namespace std;

struct Node{
    int value;
    Node* left_child;
    Node* right_child;
    Node(int val){value=val, left_child=nullptr, right_child=nullptr;}
};


Node* insert(Node* root, int val)
{
   if(root==nullptr) {root=new Node(val); return root;}
   if(root->value==val) ;
   else if(root->value>val) root->left_child=insert(root->left_child, val);
   else root->right_child=insert(root->right_child, val);
   return root;
}


void inorder(Node* root)
{
   if(root==nullptr) return;
   inorder(root->left_child);
   cout<<root->value<<" ";
   inorder(root->right_child);
}


int main()
{
    int n;// n= number of nodes
    cin>>n;
    Node* BST=nullptr;
    for(int i=0; i<n; i++)
    {
       int val;
       cin>>val;
       BST=insert(BST, val);
    }
    inorder(BST);
    return 0;
}