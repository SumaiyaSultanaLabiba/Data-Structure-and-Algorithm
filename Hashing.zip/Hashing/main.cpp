#include<iostream>
#include<vector>
#include<cstdlib>
#include<ctime>
#include "chaining.h"
#include "double_hashing.h"
#include "custom_probing.h"
using namespace std;


// generates random 'n' length words
string random_generator(int n)
{
   string word="";
   for(int i=0; i<n; i++)
   {
    int random_int = rand() % 26;
    char letter='a'+random_int;
    word+= letter;
   }
   return word;
}



int main()
{
    int initial_table_size=13;
    float cut_off=0.5;
    int c1= 1, c2= 2; // these are the constants for custom probing

    // all that are marked "1" uses the hash1, and marked "2" uses the hash2
    Chaining<string,int> chainingTable1(initial_table_size, cut_off);
    Chaining<string,int> chainingTable2(initial_table_size, cut_off);
    Double_hashing<string,int> doubleHashTable1(initial_table_size, cut_off);
    Double_hashing<string,int> doubleHashTable2(initial_table_size, cut_off);
    Custom_probing<string,int> customHashTable1(initial_table_size, cut_off, c1, c2);
    Custom_probing<string,int> customHashTable2(initial_table_size, cut_off, c1, c2);


    //"collisions_chaining1" refers to the total number of collisions during insertions using chaining appraoch and hash1 method
    int collisions_chaining1=0; 
    int collisions_chaining2=0; 
    int collisions_doubleHash1=0; 
    int collisions_doubleHash2=0; 
    int collisions_customHash1=0; 
    int collisions_customHash2=0; 


    int n=10; // n = length of each word
    int word_count=0;
    int break_condition=10000;

    vector<string> word_collection; // stores the words that are successfully inserted in each of the above hash tables
    srand(time(nullptr));


    while(true)
    {
        if(word_count==break_condition) break;
        string word=random_generator(n);
        
        if(!chainingTable1.search1(word) && !chainingTable2.search2(word) && !doubleHashTable1.search1(word)
            && !doubleHashTable2.search2(word) && !customHashTable1.search1(word) && !customHashTable2.search2(word))
        {
            word_collection.push_back(word);
            word_count++;
            collisions_chaining1+=chainingTable1.insert1(word, word_count);
            collisions_chaining2+=chainingTable2.insert2(word, word_count);
            collisions_doubleHash1+=doubleHashTable1.insert1(word, word_count);
            collisions_doubleHash2+=doubleHashTable2.insert2(word, word_count);
            collisions_customHash1+=customHashTable1.insert1(word, word_count);
            collisions_customHash2+=customHashTable2.insert2(word, word_count);
        }
    }


    //"totalHits_chaining1" refers to the total number of hits during search operation using chaining approach and hash1 method
    int totalHits_chaining1=0; 
    int totalHits_chaining2=0; 
    int totalHits_doubleHash1=0; 
    int totalHits_doubleHash2=0; 
    int totalHits_customHash1=0; 
    int totalHits_customHash2=0;

    
    for(int i=0; i<1000; i++)
    {
        int random= rand()%(word_collection.size());
        string chosen_word=word_collection[random];
        totalHits_chaining1+=chainingTable1.search_collision1(chosen_word);
        totalHits_chaining2+=chainingTable2.search_collision2(chosen_word);
        totalHits_doubleHash1+=doubleHashTable1.search_collision1(chosen_word);
        totalHits_doubleHash2+=doubleHashTable2.search_collision2(chosen_word);
        totalHits_customHash1+=customHashTable1.search_collision1(chosen_word);
        totalHits_customHash2+=customHashTable2.search_collision2(chosen_word);
    }
        

    // printing the output
    cout<<"                               "<<"Hash1"<<"                                 "<<"Hash2"<<"      "<<endl;
    cout<<"                Number of collisions"<<" Average hits"<<"   Number of collisions"<<" Average hits "<<endl;
    cout<<"Chaining                 "<<collisions_chaining1<<"           "<<float(totalHits_chaining1)/1000<<"               "<<collisions_chaining2<<"           "<<float(totalHits_chaining2)/1000<<endl;
    cout<<"Double hashing           "<<collisions_doubleHash1<<"           "<<float(totalHits_doubleHash1)/1000<<"               "<<collisions_doubleHash2<<"           "<<float(totalHits_doubleHash2)/1000<<endl;
    cout<<"Custom probing           "<<collisions_customHash1<<"           "<<float(totalHits_customHash1)/1000<<"               "<<collisions_customHash2<<"           "<<float(totalHits_customHash2)/1000<<endl;

    return 0;
}