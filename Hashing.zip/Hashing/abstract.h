#pragma once

#include<functional>
#include<cmath>
using namespace std;


// checks if prime or not
bool isPrime(int num)
{
  if(num<=1) return false;  
  for(int i=2; i*i<=num; i++)
  {
    if(num%i==0) return false;
  }
  return true;
}

// returns the next prime number
int nextPrime(int num)
{
  while(true)
  {
    if(isPrime(num)) return num;
    num++;
  }
}


//This is the abstract class for Hash Table implementation
template<typename KEY, typename VALUE>
class Hash_table
{
    public:
    virtual int insert1(const KEY& key, const VALUE& val)=0;
    virtual int insert2(const KEY& key, const VALUE& val)=0;

    virtual bool search1(const KEY& key)=0;
    virtual bool search2(const KEY& key)=0;

    virtual int search_collision1(const KEY& key)=0;
    virtual int search_collision2(const KEY& key)=0;

    virtual bool remove1(const KEY& key)=0;
    virtual bool remove2(const KEY& key)=0;

    virtual void rehash1(int old_size, int new_size)=0;
    virtual void rehash2(int old_size, int new_size)=0;

    // resembles MurmurHash
    int hash1(const KEY& key, int table_size)
    {
        int hash_value = hash<KEY>{}(key);
        if(hash_value<0) hash_value=-hash_value;
        unsigned int h=hash_value;
        h^=h>>16;
        h*=0x85ebca6b;
        h^=h>>13;
        h*=0xc2b2ae35;
        h^=h>>16;
        return static_cast<int>(h%table_size);
    }

    // resembles CityHash 
    int hash2(const KEY& key, int table_size)
    {
        int hash_value = hash<KEY>{}(key);
        if(hash_value<0) hash_value=-hash_value;
        const unsigned long long k= 0x9ddfea08eb382d69ULL;
        unsigned long long h= static_cast<unsigned long long>(hash_value)*k;
        h^=(h>>47);
        h*= k;
        return static_cast<int>(h%table_size);
    }


    // Prime based secondary hash
    int auxHash(const KEY& key, int table_size)
    {
        int hash_value = hash<KEY>{}(key);
        if(hash_value<0) hash_value=-hash_value;
        int prime= nextPrime(table_size/2);
        return prime-(hash_value%prime);
    }
};

