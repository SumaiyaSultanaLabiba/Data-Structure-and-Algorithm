#include "abstract.h"
#include<vector>
#include<list>
using namespace std;


template<typename KEY, typename VALUE>
class Chaining: public Hash_table<KEY,VALUE>
{
    protected:
    int initial_table_size;
    int current_table_size;
    int num_of_elements;
    float cut_off;
    vector<list<pair<KEY,VALUE>>> container;
    
    public:
    Chaining(int init_size, float cutoff)
    {
      this->initial_table_size=init_size; 
      this->current_table_size=init_size;
      this->num_of_elements=0;
      this->cut_off=cutoff;
      this->container.resize(init_size);
    }


    // inserts using hash1, returns the number of collisions 
    int insert1(const KEY& key, const VALUE& val) override
    {
      if(this->search1(key)) return 0;
      int index=this->hash1(key, this->current_table_size);
      int num_of_collisions=this->container[index].size();
      this->container[index].push_back({key, val});
      this->num_of_elements++;
      if(float(this->num_of_elements)/float(this->current_table_size)>=this->cut_off)
      {
        rehash1(this->current_table_size, this->current_table_size*2);
      }
      return num_of_collisions;
    }


    // inserts using hash2, returns the number of collisions 
    int insert2(const KEY& key, const VALUE& val) override
    {
      if(this->search2(key)) return 0;
      int index=this->hash2(key, this->current_table_size);
      int num_of_collisions=this->container[index].size();
      this->container[index].push_back({key, val});
      this->num_of_elements++;
      if(float(this->num_of_elements)/float(this->current_table_size)>=this->cut_off)
      {
        rehash2(this->current_table_size, this->current_table_size*2);
      }
      return num_of_collisions;
    }



    // returns whether found or not, using hash1
    bool search1(const KEY& key) override
    {
      int index=this->hash1(key, this->current_table_size);
      for(pair<KEY,VALUE> p: this->container[index])
      {
        if(p.first==key) return true;
      }
      return false;
    }



    // returns the number of hits during search operation
    int search_collision1(const KEY& key) override
    {
      int collisions=0;
      int index=this->hash1(key, this->current_table_size);
      for(pair<KEY,VALUE> p: this->container[index])
      {
        if(p.first==key) return collisions;
        else collisions++;
      }
      return collisions;
    }



    // returns whether found or not, using hash2
    bool search2(const KEY& key) override
    {
      int index=this->hash2(key, this->current_table_size);
      for(pair<KEY,VALUE> p: this->container[index])
      {
        if(p.first==key) return true;
      }
      return false;
    }



    // returns the number of hits during search operation
    int search_collision2(const KEY& key) override
    {
      int collisions=0;
      int index=this->hash2(key, this->current_table_size);
      for(pair<KEY,VALUE> p: this->container[index])
      {
        if(p.first==key) return collisions;
        else collisions++;
      }
      return collisions;
    }



    // removes an element from the table using hash1, returns whether successful in deletion or not
    bool remove1(const KEY& key) override
    {
      int index= this->hash1(key, this->current_table_size);
      for(pair<KEY,VALUE> p: this->container[index])
      {
        if(p.first==key)
        {
          this->container[index].remove({p.first, p.second});
          this->num_of_elements--;
        }
      }
      float current_cutoff= float(this->num_of_elements)/float(this->current_table_size);
      if(current_cutoff<(this->cut_off/2) && (this->current_table_size/2)>this->initial_table_size)
      {
        rehash1(this->current_table_size, this->current_table_size/2);
      }
      if(!this->search1(key)) return true;
      return false;
    }



    // removes an element from the table using hash2, returns whether successful in deletion or not
    bool remove2(const KEY& key) override
    {
      int index= this->hash2(key, this->current_table_size);
      for(pair<KEY,VALUE> p: this->container[index])
      {
        if(p.first==key)
        {
          this->container[index].remove({p.first, p.second});
          this->num_of_elements--;
        }
      }
      float current_cutoff= float(this->num_of_elements)/float(this->current_table_size);
      if(current_cutoff<(this->cut_off/2) && (this->current_table_size/2)>this->initial_table_size)
      {
        rehash2(this->current_table_size, this->current_table_size/2);
      }
      if(!this->search2(key)) return true;
      return false;
    }



    // rehashes the table using hash1
    void rehash1(int old_size, int new_size) override
    {
      vector<list<pair<KEY,VALUE>>> old_container=this->container;
      new_size=nextPrime(new_size);
      this->current_table_size=new_size;
      this->container.clear();
      this->container.resize(new_size);
      this->num_of_elements=0;
      for(list<pair<KEY,VALUE>> l: old_container)
      {
        for(pair<KEY,VALUE> p: l)
        {
          int index=this->hash1(p.first, this->current_table_size);
          this->container[index].push_back({p.first, p.second});
          this->num_of_elements++;
        }
      }
    }



    // rehashes the table using hash2
    void rehash2(int old_size, int new_size) override
    {
      vector<list<pair<KEY,VALUE>>> old_container=this->container;
      new_size=nextPrime(new_size);
      this->current_table_size=new_size;
      this->container.clear();
      this->container.resize(new_size);
      this->num_of_elements=0;
      for(list<pair<KEY,VALUE>> l: old_container)
      {
        for(pair<KEY,VALUE> p: l)
        {
          int index=this->hash2(p.first, this->current_table_size);
          this->container[index].push_back({p.first, p.second});
          this->num_of_elements++;
        }
      }
    }
};

