#include "abstract.h"
#include<vector>
#include<list>
using namespace std;


template<typename KEY, typename VALUE>
class Custom_probing: public Hash_table<KEY,VALUE>
{
    protected:
    int initial_table_size;
    int current_table_size;
    int num_of_elements;
    float cut_off;
    int c1, c2;
    vector<pair<KEY,VALUE>> container;
    vector<string> state; 
    
    public:
    Custom_probing(int init_size, float cutoff, int c1, int c2)
    {
      this->initial_table_size=init_size;  
      this->current_table_size=init_size;
      this->num_of_elements=0;
      this->cut_off=cutoff;
      this->c1=c1;
      this->c2=c2;
      this->container.resize(init_size);
      this->state.resize(init_size, "empty");
    }



    // inserts using hash1, returns the number of collisions 
    int insert1(const KEY& key, const VALUE& val) override
    {
      if(this->search1(key)) return 0;

      int primary_index=this->hash1(key, this->current_table_size);
      int secondary_index= this->auxHash(key, this->current_table_size);
      int current_index= primary_index;
      int collisions=0;

      while(this->state[current_index]=="active")
      {
        collisions++;
        current_index= (primary_index+this->c1*collisions*secondary_index+this->c2*collisions*collisions)%this->current_table_size;
      }

      this->container[current_index]={key, val};
      this->state[current_index]="active";
      this->num_of_elements++;

      if(float(this->num_of_elements)/float(this->current_table_size)>=this->cut_off)
      {
        rehash1(this->current_table_size, this->current_table_size*2);
      }
      return collisions;
    }



    // inserts using hash2, returns the number of collisions 
    int insert2(const KEY& key, const VALUE& val) override
    {
      if(this->search2(key)) return 0;

      int primary_index=this->hash2(key, this->current_table_size);
      int secondary_index= this->auxHash(key, this->current_table_size);
      int current_index= primary_index;
      int collisions=0;

      while(this->state[current_index]=="active")
      {
        collisions++;
        current_index= (primary_index+this->c1*collisions*secondary_index+this->c2*collisions*collisions)%this->current_table_size;
      }

      this->container[current_index]={key, val};
      this->state[current_index]="active";
      this->num_of_elements++;
      
      if(float(this->num_of_elements)/float(this->current_table_size)>=this->cut_off)
      {
        rehash2(this->current_table_size, this->current_table_size*2);
      }
      return collisions;
    }



    // returns whether found or not, using hash1
    bool search1(const KEY& key) override
    {
      int primary_index=this->hash1(key, this->current_table_size);
      int secondary_index= this->auxHash(key, this->current_table_size);
      int current_index= primary_index;
      int collisions=0;
      while(this->state[current_index]!="empty")
      {
        if(this->state[current_index]!="deleted" && this->container[current_index].first==key)
        {
          return true;
        }
        collisions++;
        current_index= (primary_index+this->c1*collisions*secondary_index+this->c2*collisions*collisions)%this->current_table_size;
      }
      return false;
    }



    // returns the number of hits during search operation
    int search_collision1(const KEY& key) override
    {
      int primary_index=this->hash1(key, this->current_table_size);
      int secondary_index= this->auxHash(key, this->current_table_size);
      int current_index= primary_index;
      int collisions=0;
      while(this->state[current_index]!="empty")
      {
        if(this->state[current_index]!="deleted" && this->container[current_index].first==key)
        {
          return collisions;
        }
        collisions++;
        current_index= (primary_index+this->c1*collisions*secondary_index+this->c2*collisions*collisions)%this->current_table_size;
      }
      return collisions;
    }



    // returns whether found or not, using hash2
    bool search2(const KEY& key) override
    {
      int primary_index=this->hash2(key, this->current_table_size);
      int secondary_index= this->auxHash(key, this->current_table_size);
      int current_index= primary_index;
      int collisions=0;
      while(this->state[current_index]!="empty")
      {
        if(this->state[current_index]!="deleted" && this->container[current_index].first==key)
        {
          return true;
        }
        collisions++;
        current_index= (primary_index+this->c1*collisions*secondary_index+this->c2*collisions*collisions)%this->current_table_size;
      }
      return false;
    }



    // returns the number of hits during search operation
    int search_collision2(const KEY& key) override
    {
      int primary_index=this->hash2(key, this->current_table_size);
      int secondary_index= this->auxHash(key, this->current_table_size);
      int current_index= primary_index;
      int collisions=0;
      while(this->state[current_index]!="empty")
      {
        if(this->state[current_index]!="deleted" && this->container[current_index].first==key)
        {
          return collisions;
        }
        collisions++;
        current_index= (primary_index+this->c1*collisions*secondary_index+this->c2*collisions*collisions)%this->current_table_size;
      }
      return collisions;
    }



    // removes an element from the table using hash1, returns whether successful in deletion or not
    bool remove1(const KEY& key) override
    {
      int primary_index=this->hash1(key, this->current_table_size);
      int secondary_index= this->auxHash(key, this->current_table_size);
      int current_index= primary_index;
      int collisions=0;
      while(this->state[current_index]!="empty")
      {
        if(this->state[current_index]=="active" && this->container[current_index].first==key)
        {
          this->state[current_index]="deleted";
          this->num_of_elements--;
          return true;
        }
        collisions++;
        current_index= (primary_index+this->c1*collisions*secondary_index+this->c2*collisions*collisions)%this->current_table_size;
      }

      float current_cutoff= float(this->num_of_elements)/float(this->current_table_size);
      if(current_cutoff<this->cut_off/2 && this->current_table_size/2>this->initial_table_size)
      {
        rehash1(this->current_table_size, this->current_table_size/2);
      }
      return false;
    }



    // removes an element from the table using hash2, returns whether successful in deletion or not
    bool remove2(const KEY& key) override
    {
      int primary_index=this->hash2(key, this->current_table_size);
      int secondary_index= this->auxHash(key, this->current_table_size);
      int current_index= primary_index;
      int collisions=0;
      while(this->state[current_index]!="empty")
      {
        if(this->state[current_index]=="active" && this->container[current_index].first==key)
        {
          this->state[current_index]="deleted";
          this->num_of_elements--;
          return true;
        }
        collisions++;
        current_index= (primary_index+this->c1*collisions*secondary_index+this->c2*collisions*collisions)%this->current_table_size;
      }
      float current_cutoff= float(this->num_of_elements)/float(this->current_table_size);
      if(current_cutoff<this->cut_off/2 && this->current_table_size/2>this->initial_table_size)
      {
        rehash2(this->current_table_size, this->current_table_size/2);
      }
      return false;
    }



    // rehashes the table using hash1
    void rehash1(int old_size, int new_size) override
    {
      vector<pair<KEY,VALUE>> old_container=this->container;
      vector<string> old_state=this->state;
      new_size=nextPrime(new_size);
      this->current_table_size=new_size;
      this->container.clear();
      this->state.clear();
      this->container.resize(new_size);
      this->state.resize(new_size, "empty");
      this->num_of_elements=0;

      for(int i=0; i<old_size; i++)
      {
        if(old_state[i]=="active")
        {
          pair<KEY,VALUE> p=old_container[i];
          int primary_index=this->hash1(p.first, this->current_table_size);
          int secondary_index= this->auxHash(p.first, this->current_table_size);
          int current_index= primary_index;
          int count=0;

          while(this->state[current_index]=="active")
          {
            count++;
            current_index= (primary_index+this->c1*count*secondary_index+this->c2*count*count)%this->current_table_size;
          }
          this->container[current_index]={p.first, p.second};
          this->state[current_index]="active";
          this->num_of_elements++;
        }
      }
    }



    // rehashes the table using hash2
    void rehash2(int old_size, int new_size) override
    {
      vector<pair<KEY,VALUE>> old_container=this->container;
      vector<string> old_state=this->state;
      new_size=nextPrime(new_size);
      this->current_table_size=new_size;
      this->container.clear();
      this->state.clear();
      this->container.resize(new_size);
      this->state.resize(new_size, "empty");
      this->num_of_elements=0;

      for(int i=0; i<old_size; i++)
      {
        if(old_state[i]=="active")
        {
          pair<KEY,VALUE> p=old_container[i];
          int primary_index=this->hash2(p.first, this->current_table_size);
          int secondary_index= this->auxHash(p.first, this->current_table_size);
          int current_index= primary_index;
          int count=0;

          while(this->state[current_index]=="active")
          {
            count++;
            current_index= (primary_index+this->c1*count*secondary_index+this->c2*count*count)%this->current_table_size;
          }
          this->container[current_index]={p.first, p.second};
          this->state[current_index]="active";
          this->num_of_elements++;
        }
      }
    }
};

