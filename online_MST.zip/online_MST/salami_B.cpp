#include<iostream>
#include<bits/stdc++.h>
using namespace std;



//find operation with path compression
int find(vector<int>& parent, int child)
{
   if(parent[child]==child) return child;
   else
   {
      parent[child]=find(parent, parent[child]);
      return parent[child];
   }
}


//Kruskal's algorithm
void kruskal(int n, int m, priority_queue<pair<float,pair<int,int>>, vector<pair<float,pair<int,int>>>, greater<pair<float,pair<int,int>>>>& pq, vector<vector<string>>& conn_type)
{
    vector<pair<int,int>> edges(m); // list of (u,v) pairs in non-decreasing cost order 
    vector<float> cost(m); // corresponding ordered cost for each edge
    for(int i=0; i<m; i++)
    {
        pair<float,pair<int,int>> p=pq.top();
        pq.pop();
        edges[i]={p.second.first, p.second.second};
        cost[i]=p.first;
    }

    vector<int> parent(n, -1);
    for(int i=0; i<n; i++) parent[i]=i;

    vector<int> rank(n, 0); // height of each subtree rooted at the index node

    vector<pair<int,int>> chosen_edges;
    float total_length=0;
    int rail_count=0;
    float rail_length=0.0;

    for(int i=0; i<m; i++)
    {
        int u, v;
        float w;
        u=edges[i].first;
        v=edges[i].second;
        w=cost[i];

        int parent_u=find(parent,u);
        int parent_v=find(parent,v);

        if(parent_u!=parent_v)
        {
           if(rank[parent_u]>rank[parent_v])
           {
             parent[parent_v]=parent_u;
           } 
           else if(rank[parent_u]<rank[parent_v]) 
           {
             parent[parent_u]=parent_v; 
           }
           else
           {
             parent[parent_v]=parent_u; 
             rank[parent_u]++;
           }
    
           chosen_edges.push_back({u,v});
           total_length+=w;
           if(conn_type[u][v]=="rail") {rail_count++; rail_length+=w;}
        }
    }

    cout<<"Num of states:"<<rail_count+1<<", Total road length: "<<(total_length-rail_length)<<", Total railroad length: "<<rail_length<<endl;
}



int main()
{
    int n;
    float r;
    cin>>n>>r;

    vector<int> x_coordinates(n);
    vector<int> y_coordinates(n);

    for(int i=0; i<n; i++)
    {
      cin>>x_coordinates[i];
      cin>>y_coordinates[i];
    }

    priority_queue<pair<float,pair<int,int>>, vector<pair<float,pair<int,int>>>, greater<pair<float,pair<int,int>>>> pq; //a min-heap to automatically order the edges
    vector<vector<string>> conn_type(n, vector<string>(n));
    
    for(int u=0; u<n; u++)
    {
        for(int v=0; v<n; v++)
        {
            if(u>=v) continue;
            float w=sqrt((x_coordinates[u]-x_coordinates[v])*(x_coordinates[u]-x_coordinates[v])+(y_coordinates[u]-y_coordinates[v])*(y_coordinates[u]-y_coordinates[v]));
            if(w<=r) conn_type[u][v]="road";
            else conn_type[u][v]="rail";
            pq.push({w, {u, v}});
        }
    }

    kruskal(n, (n*(n-1))/2, pq, conn_type);
    return 0;
}