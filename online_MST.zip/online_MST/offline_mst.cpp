#include<iostream>
#include<bits/stdc++.h>
using namespace std;


//Prim's algorithm
void prim(vector<vector<pair<int, int>>>& adjList, int n, int root)
{
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> not_visited;// a min-heap to store all nodes with their keys like (key,node) pair
    vector<pair<int,int>> chosen_edges;
    vector<bool> visited(n, false);
    vector<int> keys(n, INT_MAX);
    vector<int> parent(n, -1);
    not_visited.push({0, root});
    keys[root]=0;
    parent[root]=root;
    int total_cost=0;

    while(!not_visited.empty())
    {
      pair<int,int> current=not_visited.top();
      not_visited.pop();
      int u=current.second;
      if(visited[u]) continue;

      for(pair<int,int> p: adjList[u])
      {
        int v,w;
        v=p.first;
        w=p.second;

        if(!visited[v] && keys[v]>w)
        {
        keys[v]=w;
        parent[v]=u;
        not_visited.push({keys[v],v});
        }
      }

      visited[u]=true;
      if(u!=root)
      {
        chosen_edges.push_back({parent[u], u});
        total_cost+=keys[u];
      }
    }

    cout<<"Total weight "<<total_cost<<endl;
    cout<<"Root node "<<root<<endl;
    for(pair<int,int> p: chosen_edges)
    {
        cout<<p.first<<" "<<p.second<<endl;
    }
}



//find operation with path compression
int find(vector<int>& parent, int child)
{
   if(parent[child]==child) return child;
   else
   {
      parent[child]=find(parent, parent[child]);
      return parent[child];
   }
}


//Kruskal's algorithm
void kruskal(int n, int m, priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>>>& pq)
{
    vector<pair<int,int>> edges(m); // list of (u,v) pairs in non-decreasing cost order 
    vector<int> cost(m); // corresponding ordered cost for each edge
    for(int i=0; i<m; i++)
    {
        pair<int,pair<int,int>> p=pq.top();
        pq.pop();
        edges[i]={p.second.first, p.second.second};
        cost[i]=p.first;
    }

    vector<int> parent(n, -1);
    for(int i=0; i<n; i++) parent[i]=i;

    vector<int> rank(n, 0); // height of each subtree rooted at the index node

    vector<pair<int,int>> chosen_edges;
    int total_cost=0;

    for(int i=0; i<m; i++)
    {
        int u, v, w;
        u=edges[i].first;
        v=edges[i].second;
        w=cost[i];

        int parent_u=find(parent,u);
        int parent_v=find(parent,v);

        if(parent_u!=parent_v)
        {
           if(rank[parent_u]>rank[parent_v])
           {
             parent[parent_v]=parent_u;
           } 
           else if(rank[parent_u]<rank[parent_v]) 
           {
             parent[parent_u]=parent_v; 
           }
           else
           {
             parent[parent_v]=parent_u; 
             rank[parent_u]++;
           }
    
           chosen_edges.push_back({u,v});
           total_cost+=w;
        }
    }

    cout<<"Total weight "<<total_cost<<endl;
    for(pair<int,int> p: chosen_edges)
    {
        cout<<p.first<<" "<<p.second<<endl;
    }
}



int main()
{
    int n, m;//n= number of nodes, m=number of edges
    cin>>n>>m;

    vector<vector<pair<int, int>>> adjList(n);//stores all input edges
    priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>>> pq; //a min-heap to automatically order the edges
    
    for(int i=0; i<m; i++)
    {
        int u, v, w;
        cin>>u>>v>>w;
        adjList[u].push_back({v,w});
        adjList[v].push_back({u,w});
        pq.push({w,{u,v}});
    }

    int root=0;
    cin>>root;

    prim(adjList, n, root);
    kruskal(n, m, pq);

    return 0;
}