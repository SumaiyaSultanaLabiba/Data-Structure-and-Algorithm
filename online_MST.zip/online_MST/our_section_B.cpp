#include<iostream>
#include<bits/stdc++.h>
using namespace std;


//find operation with path compression
int find(vector<int>& parent, int child)
{
   if(parent[child]==child) return child;
   else
   {
      parent[child]=find(parent, parent[child]);
      return parent[child];
   }
}


//Kruskal's algorithm returning latency difference
int kruskal(int n, int m, priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>>> pq, int starting_edge)
{
    vector<pair<int,int>> edges(m+1, {0,0}); // list of (u,v) pairs in non-decreasing cost order 
    vector<int> cost(m+1, 0); // corresponding ordered cost for each edge
    for(int i=1; i<=m; i++)
    {
        pair<int,pair<int,int>> p=pq.top();
        pq.pop();
        edges[i]={p.second.first, p.second.second};
        cost[i]=p.first;
    }

    vector<int> parent(n+1, -1);
    for(int i=1; i<=n; i++) parent[i]=i;

    vector<int> rank(n+1, 0); // height of each subtree rooted at the index node

    vector<pair<int,int>> chosen_edges;
    int total_cost=0;

    int highest_latency=INT_MIN;
    int lowest_latency=INT_MAX;

    for(int i=1; i<=m; i++)
    {
        if(i<starting_edge) continue;
        int u, v, w;
        u=edges[i].first;
        v=edges[i].second;
        w=cost[i];

        int parent_u=find(parent,u);
        int parent_v=find(parent,v);

        if(parent_u!=parent_v)
        {
           if(rank[parent_u]>rank[parent_v])
           {
             parent[parent_v]=parent_u;
           } 
           else if(rank[parent_u]<rank[parent_v]) 
           {
             parent[parent_u]=parent_v; 
           }
           else
           {
             parent[parent_v]=parent_u; 
             rank[parent_u]++;
           }
    
           chosen_edges.push_back({u,v});
           total_cost+=w;
           if(highest_latency<w) highest_latency=w;
           if(lowest_latency>w) lowest_latency=w;
        }
    }

    if(highest_latency==INT_MIN || lowest_latency==INT_MAX || chosen_edges.size()<n-1) return -1;
    return (highest_latency-lowest_latency);
}



int main()
{
    int n, m;//n= number of nodes, m=number of edges
    cin>>n>>m;

    priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>>> pq; //a min-heap to automatically order the edges
    
    for(int i=1; i<=m; i++)
    {
        int u, v, w;
        cin>>u>>v>>w;
        pq.push({w,{u,v}});
    }

    int minimum_latency_difference=INT_MAX;
    for(int starting_edge=1; starting_edge<=m; starting_edge++)
    {
      int current=kruskal(n, m, pq, starting_edge);
      if(current==-1) continue;
      if(current<minimum_latency_difference)
      {
        minimum_latency_difference=current;
      }
    }

    if(minimum_latency_difference==INT_MAX) cout<<-1<<endl; 
    else cout<<minimum_latency_difference<<endl;
    return 0;
}