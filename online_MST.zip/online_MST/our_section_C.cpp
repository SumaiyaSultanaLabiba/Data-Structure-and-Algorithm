#include<iostream>
#include<bits/stdc++.h>
using namespace std;

int absolute(int n)
{
    if (n>=0) return n;
    return -n;
}

int min(int a, int b, int c)
{
    if(a<=b && a<=c) return a;
    else if(b<=a && b<=c) return b;
    return c;
}

//find operation with path compression
int find(vector<int>& parent, int child)
{
   if(parent[child]==child) return child;
   else
   {
      parent[child]=find(parent, parent[child]);
      return parent[child];
   }
}


//Kruskal's algorithm
void kruskal(int n, int m, priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>>>& pq)
{
    vector<pair<int,int>> edges(m); // list of (u,v) pairs in non-decreasing cost order 
    vector<int> cost(m); // corresponding ordered cost for each edge
    for(int i=0; i<m; i++)
    {
        pair<int,pair<int,int>> p=pq.top();
        pq.pop();
        edges[i]={p.second.first, p.second.second};
        cost[i]=p.first;
    }

    vector<int> parent(n, -1);
    for(int i=0; i<n; i++) parent[i]=i;

    vector<int> rank(n, 0); // height of each subtree rooted at the index node

    vector<pair<int,int>> chosen_edges;
    int total_cost=0;

    for(int i=0; i<m; i++)
    {
        int u, v, w;
        u=edges[i].first;
        v=edges[i].second;
        w=cost[i];

        int parent_u=find(parent,u);
        int parent_v=find(parent,v);

        if(parent_u!=parent_v)
        {
           if(rank[parent_u]>rank[parent_v])
           {
             parent[parent_v]=parent_u;
           } 
           else if(rank[parent_u]<rank[parent_v]) 
           {
             parent[parent_u]=parent_v; 
           }
           else
           {
             parent[parent_v]=parent_u; 
             rank[parent_u]++;
           }
    
           chosen_edges.push_back({u,v});
           total_cost+=w;
        }
    }

    cout<<"Total weight "<<total_cost<<endl;
    for(pair<int,int> p: chosen_edges)
    {
        cout<<p.first<<" "<<p.second<<endl;
    }
}



int main()
{
    int n;//n= number of nodes
    cin>>n;

    vector<pair<int, int>> x_coordinates(n);
    vector<pair<int, int>> y_coordinates(n);
    vector<pair<int, int>> z_coordinates(n);

    for(int count=0; count<n; count++)
    {
        int i, j, k;
        cin>>i>>j>>k;
        x_coordinates[count]={count, i};
        y_coordinates[count]={count, j};
        z_coordinates[count]={count, k};
    }

    sort(x_coordinates.begin(), x_coordinates.end(), [](const pair<int,int>& a, const pair<int,int>& b) {return a.second<b.second;});
    sort(y_coordinates.begin(), y_coordinates.end(), [](const pair<int,int>& a, const pair<int,int>& b) {return a.second<b.second;});
    sort(z_coordinates.begin(), z_coordinates.end(), [](const pair<int,int>& a, const pair<int,int>& b) {return a.second<b.second;});


    priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>>> pq; //a min-heap to automatically order the edges

    for(int i=0; i<n-1; i++)
    {
        int u=x_coordinates[i].first;
        int v=x_coordinates[i+1].first;
        int w=min(absolute(x_coordinates[i].second-x_coordinates[i+1].second), absolute(y_coordinates[i].second-y_coordinates[i+1].second), absolute(z_coordinates[i].second-z_coordinates[i+1].second));
        pq.push({w, {u,v}});
    }

    for(int i=0; i<n-1; i++)
    {
        int u=y_coordinates[i].first;
        int v=y_coordinates[i+1].first;
        int w=min(absolute(x_coordinates[i].second-x_coordinates[i+1].second), absolute(y_coordinates[i].second-y_coordinates[i+1].second), absolute(z_coordinates[i].second-z_coordinates[i+1].second));
        pq.push({w, {u,v}});
    }

    for(int i=0; i<n-1; i++)
    {
        int u=z_coordinates[i].first;
        int v=z_coordinates[i+1].first;
        int w=min(absolute(x_coordinates[i].second-x_coordinates[i+1].second), absolute(y_coordinates[i].second-y_coordinates[i+1].second), absolute(z_coordinates[i].second-z_coordinates[i+1].second));
        pq.push({w, {u,v}});
    }

    kruskal(n, 3*(n-1), pq);
    return 0;
}