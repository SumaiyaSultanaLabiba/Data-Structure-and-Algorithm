#include<iostream>
#include "custom_probing.h"


int main()
{
    int initial_table_size=13;
    float cut_off=0.5;
    int c1= 1, c2= 2; 

    Custom_probing<int,int> intersection1(initial_table_size, cut_off, c1, c2);
    Custom_probing<int,int> unioon1(initial_table_size, cut_off, c1, c2);
    Custom_probing<int,int> difference1(initial_table_size, cut_off, c1, c2);

    Custom_probing<int,int> table1(initial_table_size, cut_off, c1, c2);
    Custom_probing<int,int> table2(initial_table_size, cut_off, c1, c2);

    vector<int> first_set;
    vector<int> second_set;

    int count1=0;
    cin>>count1;

    for(int i=0; i<count1; i++)
    {
        int element=0;
        cin>>element;
        table1.insert1(element, element);
        unioon1.insert1(element,element);
        first_set.push_back(element);
    }

    int count2=0;
    cin>>count2;

    for(int i=0; i<count2; i++)
    {
        int element=0;
        cin>>element;
        table2.insert2(element, element);
        unioon1.insert1(element,element);
        second_set.push_back(element);
        if(table1.search1(element)) intersection1.insert1(element, element);
    }

    cout<<"Union: ";
    unioon1.printAllKeys();

    //
    for(int e: first_set)
    {
        if(!table2.search2(e)) difference1.insert1(e,e);
    }

    cout<<"Intersection: ";
    intersection1.printAllKeys();

    cout<<"Difference: ";
    difference1.printAllKeys();

    return 0;
}