#include<iostream>
#include<vector>
#include<cstdlib>
#include<ctime>
#include "../double_hashing.h"
#include "../custom_probing.h"
using namespace std;


int initial_table_size=13;
float cut_off=0.5;
int c1= 1, c2= 2; // these are the constants for custom probing


void INSERT(int group_id, int user_id, string permission, Double_hashing<int,Custom_probing<int,string>*>& outer1)
{
    if(!outer1.search1(group_id))
    {
        Custom_probing<int,string>* inner2=new Custom_probing<int,string>(initial_table_size, cut_off, c1, c2);
        inner2->insert2(user_id, permission);
        outer1.insert1(group_id, inner2);
    }
    else
    {
        if(outer1.getValue1(group_id)->search2(user_id)) ;
        else
        {
            outer1.getValue1(group_id)->insert2(user_id, permission);
        }
    }
}


void SEARCH1(int group_id, int user_id, Double_hashing<int,Custom_probing<int,string>*>& outer1)
{
    if(!outer1.search1(group_id))
    {
        cout<<"Not found"<<endl;
    }
    else
    {
        if(outer1.getValue1(group_id)->search2(user_id))
        {
            cout<<outer1.getValue1(group_id)->getValue2(user_id)<<endl;
        }
        else
        {
            cout<<"Not found"<<endl;
        }
    }
}


void SEARCH2(int group_id, Double_hashing<int,Custom_probing<int,string>*>& outer1) 
{
    if(!outer1.search1(group_id))
    {
        cout<<"Not found"<<endl;
    }
    else
    {
        outer1.getValue1(group_id)->printAllData();
    }
}


void DELETE(int group_id, int user_id, Double_hashing<int,Custom_probing<int,string>*>& outer1)
{
    if(!outer1.search1(group_id))
    {
        cout<<"Not found"<<endl;
    }
    else
    {
        if(outer1.getValue1(group_id)->search2(user_id))
        {
            cout<<group_id<<" "<<user_id;
            outer1.getValue1(group_id)->remove2(user_id);
        }
        else
        {
            cout<<"Not found"<<endl;
        }
    }
}



int main()
{
    // all that are marked "1" uses the hash1, and marked "2" uses the hash
    Double_hashing<int,Custom_probing<int,string>*> outer1(initial_table_size, cut_off);//outer table
    //inner table: Custom_probing<int,string> inner2(initial_table_size, cut_off, c1, c2);

    int N=0, Q=0;
    cin>>N>>Q;
    for(int i=0; i<Q; i++)
    {
        string command;
        cin>>command;
        if(command=="INSERT")
        {
            int group_id=0, user_id=0;
            string permission;
            cin>>group_id>>user_id>>permission;
            INSERT(group_id, user_id, permission, outer1);
        }

        if(command=="SEARCH1")
        {
            int group_id=0, user_id=0;
            cin>>group_id>>user_id;
            SEARCH1(group_id, user_id, outer1);
        }

        if(command=="SEARCH2")
        {
            int group_id=0;
            cin>>group_id;
            SEARCH2(group_id, outer1);
        }

        if(command=="DELETE")
        {
            int group_id=0, user_id=0;
            cin>>group_id>>user_id;
            DELETE(group_id, user_id, outer1);
        }
    }

    return 0;
}