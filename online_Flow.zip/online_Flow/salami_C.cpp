#include<iostream>
#include<bits/stdc++.h>
using namespace std;


void BFS(int n, int s, int t, vector<vector<long long int>>& residual_graph, vector<pair<pair<int,int>, long long int>>& augmenting_path)
{
    queue<int> q;
    vector<bool> visited(n+1, false);
    vector<int> parent(n+1, -1);

    q.push(s);
    visited[s]=true;

    while(!q.empty())
    {
        int current=q.front();
        q.pop();
        for(int v=1; v<=n; v++)
        {
            if(residual_graph[current][v]>0 && !visited[v])
            {
                parent[v]=current;
                visited[v]=true;
                q.push(v);
            }
        }
    }

    if(!visited[t]) return;
    int u=parent[t];
    int v=t;
    while(u!=-1)
    {
        augmenting_path.push_back({{u,v}, residual_graph[u][v]});
        v=u;
        u=parent[v];
    }
}



long long int edmonds_karp(int n, int s, int t, vector<vector<long long int>>& graph)
{
    vector<vector<long long int>> residual_graph(n+1, vector<long long int>(n+1, 0));
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            residual_graph[i][j]=graph[i][j];
        }
    }

    long long int max_flow=0;
    while(true)
    {
      vector<pair<pair<int,int>, long long int>> augmenting_path;
      BFS(n, s, t, residual_graph, augmenting_path);

      if(augmenting_path.size()==0) break;

      long long int min_weight=INT_MAX;
      for(pair<pair<int,int>, long long int> p: augmenting_path)
      {
        if(p.second<min_weight) min_weight=p.second;
      }

      max_flow+=min_weight;
      for(pair<pair<int,int>, long long int> p: augmenting_path)
      {
        int u=p.first.first;
        int v=p.first.second;
        residual_graph[u][v]-=min_weight;
        residual_graph[v][u]+=min_weight;
      }
    }
    return max_flow;
}



int main()
{
    int num_of_testcases=0;
    cin>>num_of_testcases;

    for(int count=1; count<=num_of_testcases; count++)
    {
    int num_of_gang_members=0, num_of_potential_partners=0;
    cin>>num_of_gang_members>>num_of_potential_partners;

    vector<int> experience_gang(num_of_gang_members+1, 0);
    vector<int> age_gang(num_of_gang_members+1, 20);
    vector<int> criminal_record_gang(num_of_gang_members+1, 0);
    vector<int> origin_gang(num_of_gang_members+1, 0);
    vector<int> weapon_gang(num_of_gang_members+1, 0);
    vector<int> trust_gang(num_of_gang_members+1, 1);
    vector<int> language_gang(num_of_gang_members+1, 1);

    for(int i=1; i<=num_of_gang_members; i++)
    {
        cin>>experience_gang[i];
        cin>>age_gang[i];
        cin>>criminal_record_gang[i];
        cin>>origin_gang[i];
        cin>>weapon_gang[i];
        cin>>trust_gang[i];
        cin>>language_gang[i];
    }

    vector<int> experience_partners(num_of_potential_partners+1, 0);
    vector<int> age_partners(num_of_potential_partners+1, 20);
    vector<int> criminal_record_partners(num_of_potential_partners+1, 0);
    vector<int> origin_partners(num_of_potential_partners+1, 0);
    vector<int> weapon_partners(num_of_potential_partners+1, 0);
    vector<int> trust_partners(num_of_potential_partners+1, 1);
    vector<int> language_partners(num_of_potential_partners+1, 1);

    for(int i=1; i<=num_of_potential_partners; i++)
    {
        cin>>experience_partners[i];
        cin>>age_partners[i];
        cin>>criminal_record_partners[i];
        cin>>origin_partners[i];
        cin>>weapon_partners[i];
        cin>>trust_partners[i];
        cin>>language_partners[i];
    }


    int V=num_of_gang_members+num_of_potential_partners+2; // V = number of vertices
    int s=1, t=V; // s = source, t = sink

    vector<vector<long long int>> graph(V+1, vector<long long int>(V+1, 0));//stores the capacity of the (u,v) edge, actually is an adjacency matrix

    for(int i=1; i<=num_of_gang_members; i++)
    {
        graph[s][i+1]=1;
    }

    for(int j=1; j<=num_of_potential_partners; j++)
    {
        graph[j+1+num_of_gang_members][t]=1;
    }

    for(int i=1; i<=num_of_gang_members; i++)
    {
        for(int j=1; j<=num_of_potential_partners; j++)
        {
            bool conditions=true;
            conditions= conditions && (abs(experience_gang[i]-experience_partners[j])<=12);
            conditions= conditions && (abs(age_gang[i]-age_partners[j])<=5);
            conditions= conditions && (criminal_record_gang[i]==criminal_record_partners[j]);
            conditions= conditions && (origin_gang[i]==origin_partners[j]);
            conditions= conditions && (weapon_gang[i]==1 || weapon_partners[j]);
            conditions= conditions && (trust_gang[i]+trust_partners[j]>=10);
            conditions= conditions && (language_gang[i] & language_partners[j]);

            if(conditions)
            {
                graph[i+1][j+1+num_of_gang_members]=1;
            }
        }
    }

    cout<<"Case "<<count<<": "<<edmonds_karp(V, s, t, graph)<<endl;
    }
    return 0;
}

/*
5
2 2
10 30 0 1 1 8 7
5 20 0 1 0 6 3
11 25 0 1 1 7 5
15 35 0 0 0 5 1
1 1
10 30 1 1 1 5 7
10 30 0 0 1 6 3
3 3
15 35 1 1 1 9 7
8 28 1 0 1 8 5
20 40 0 1 0 7 3
10 30 1 1 1 6 7
18 38 1 0 0 5 5
5 25 0 0 1 8 1
2 3
12 32 1 1 1 8 6
5 25 0 0 1 7 4
8 28 1 1 0 6 7
15 35 0 1 1 5 2
20 30 1 0 1 4 3
4 4
10 30 1 1 1 9 7
15 35 0 0 1 8 5
8 28 1 1 0 7 3
12 32 0 0 1 6 1
12 32 1 1 1 8 7
10 30 0 0 0 7 5
14 34 1 0 1 5 3
5 25 0 1 1 9 2
*/