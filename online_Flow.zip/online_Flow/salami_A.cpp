#include<iostream>
#include<bits/stdc++.h>
using namespace std;


void BFS(int n, int s, int t, vector<vector<long long int>>& residual_graph, vector<int>& augmenting_path)
{
    queue<int> q;
    vector<bool> visited(n+1, false);
    vector<int> parent(n+1, -1);

    q.push(s);
    visited[s]=true;

    while(!q.empty())
    {
        int current=q.front();
        q.pop();
        for(int v=1; v<=n; v++)
        {
            if(residual_graph[current][v]>0 && !visited[v])
            {
                parent[v]=current;
                visited[v]=true;
                q.push(v);
            }
        }
    }

    if(!visited[t]) return;
    int u=t;
    while(u!=-1)
    {
        augmenting_path.push_back(u);
        u=parent[u];
    }

    reverse(augmenting_path.begin(), augmenting_path.end());
}



void edmonds_karp(int n, int m, int s, int t, vector<vector<long long int>>& graph, vector<vector<int>>& all_possible_routes)
{
    vector<vector<long long int>> residual_graph(n+1, vector<long long int>(n+1, 0));
    
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            residual_graph[i][j]=graph[i][j];
        }
    }

    while(true)
    {
      vector<int> augmenting_path;
      BFS(n, s, t, residual_graph, augmenting_path);

      if(augmenting_path.size()==0) break;
      all_possible_routes.push_back(augmenting_path);

      for(int i=0; i<=augmenting_path.size()-2; i++)
      {
        int u=augmenting_path[i];
        int v=augmenting_path[i+1];
        residual_graph[u][v]-=1;
        residual_graph[v][u]+=1;
      }
    }
}



int main()
{
    int num_of_testcases=0;
    cin>>num_of_testcases;
    for(int count=1; count<=num_of_testcases; count++)
    {
    int n, m; // n = number of nodes, m = number of directed edges
    cin>>n>>m;
    int s=1, t=n;// s = source, t = sink

    vector<vector<long long int>> graph(n+1, vector<long long int>(n+1, 0));//stores the capacity of the (u,v) edge, actually is an adjacency matrix

    for(int i=1; i<=m; i++)
    {
        int u, v;
        long long int w=1;
        cin>>u>>v;
        graph[u][v]+=w;
    }

    vector<vector<int>> all_possible_routes;
    edmonds_karp(n, m, s, t, graph, all_possible_routes);

    cout<<"Case "<<count<<": "<<all_possible_routes.size()<<endl;
    if(all_possible_routes.size()==0) 
    {
        cout<<"No escape route possible! The Professor needs a new plan."<<endl;
    }
    else
    {
        for(vector<int> routes: all_possible_routes)
        {
          int length=routes.size();
          for(int i=0; i<length; i++)
          {
            cout<<routes[i];
            if(i==length-1) continue;
            cout<<"->";
          }
          cout<<endl;
        }
    }
    }
    return 0;
}

/*
5
6 8
1 2
1 3
2 4
3 4
3 5
4 6
5 6
2 5
4 4
1 2
2 3
4 3
4 1
7 10
1 2
1 3
2 4
2 5
3 5
3 6
4 7
5 7
6 7
5 6
5 7
1 2
1 3
2 4
3 4
3 5
4 5
2 5
8 12
1 2
1 3
1 4
2 5
3 5
3 6
4 6
5 7
5 8
6 7
6 8
7 8
*/