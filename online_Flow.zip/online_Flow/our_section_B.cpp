#include<iostream>
#include<bits/stdc++.h>
using namespace std;


void BFS(int n, int s, int t, vector<vector<long long int>>& residual_graph, vector<pair<pair<int,int>, long long int>>& augmenting_path)
{
    queue<int> q;
    vector<bool> visited(n+1, false);
    vector<int> parent(n+1, -1);

    q.push(s);
    visited[s]=true;

    while(!q.empty())
    {
        int current=q.front();
        q.pop();
        for(int v=1; v<=n; v++)
        {
            if(residual_graph[current][v]>0 && !visited[v])
            {
                parent[v]=current;
                visited[v]=true;
                q.push(v);
            }
        }
    }

    if(!visited[t]) return;
    int u=parent[t];
    int v=t;
    while(u!=-1)
    {
        augmenting_path.push_back({{u,v}, residual_graph[u][v]});
        v=u;
        u=parent[v];
    }
}



long long int edmonds_karp(int n, int s, int t, vector<vector<long long int>>& graph)
{
    vector<vector<long long int>> residual_graph(n+1, vector<long long int>(n+1, 0));
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            residual_graph[i][j]=graph[i][j];
        }
    }

    long long int max_flow=0;
    while(true)
    {
      vector<pair<pair<int,int>, long long int>> augmenting_path;
      BFS(n, s, t, residual_graph, augmenting_path);

      if(augmenting_path.size()==0) break;

      long long int min_weight=LLONG_MAX;
      for(pair<pair<int,int>, long long int> p: augmenting_path)
      {
        if(p.second<min_weight) min_weight=p.second;
      }

      max_flow+=min_weight;
      for(pair<pair<int,int>, long long int> p: augmenting_path)
      {
        int u=p.first.first;
        int v=p.first.second;
        residual_graph[u][v]-=min_weight;
        residual_graph[v][u]+=min_weight;
      }
    }
    return max_flow;
}



int main()
{
    int N, M;
    cin>>N>>M;
    int s=1, t=N;// s = source, t = sink

    vector<vector<long long int>> graph(N+1, vector<long long int>(N+1, 0));//stores the capacity of the (u,v) edge, actually is an adjacency matrix

    for(int i=1; i<=M; i++)
    {
        int u, v;
        long long int w;
        cin>>u>>v>>w;
        graph[u][v]+=w;
    }

    int no_flyover_maxflow=edmonds_karp(N, s, t, graph);

    int P=0; //  P = number of flyovers
    cin>>P;
    vector<pair<pair<int,int>,int>> flyovers(P+1, {{0,0},0});
    for(int i=1; i<=P; i++)
    {
        int u, v, w;
        cin>>u>>v>>w;
        flyovers[i]={{u,v}, w};
    }


    vector<int> indices_of_useful_flyovers;
    for(int i=1; i<=P; i++)
    {
        int u, v, w;
        u=flyovers[i].first.first;
        v=flyovers[i].first.second;
        w=flyovers[i].second;

        graph[u][v]+=w;
        if(edmonds_karp(N, s, t, graph)>no_flyover_maxflow) indices_of_useful_flyovers.push_back(i);
        graph[u][v]-=w;
    }

    if(indices_of_useful_flyovers.size()==0) cout<<"None"<<endl;
    else
    {
        for(int f: indices_of_useful_flyovers)
        {
            cout<<f<<" ";
        }
        cout<<endl;
    }
    return 0;
}
