#include<iostream>
#include<bits/stdc++.h>
using namespace std;


void BFS(int n, int s, int t, vector<vector<long long int>>& residual_graph, vector<pair<pair<int,int>, long long int>>& augmenting_path)
{
    queue<int> q;
    vector<bool> visited(n+1, false);
    vector<int> parent(n+1, -1);

    q.push(s);
    visited[s]=true;

    while(!q.empty())
    {
        int current=q.front();
        q.pop();
        for(int v=1; v<=n; v++)
        {
            if(residual_graph[current][v]>0 && !visited[v])
            {
                parent[v]=current;
                visited[v]=true;
                q.push(v);
            }
        }
    }

    if(!visited[t]) return;
    int u=parent[t];
    int v=t;
    while(u!=-1)
    {
        augmenting_path.push_back({{u,v}, residual_graph[u][v]});
        v=u;
        u=parent[v];
    }
}



long long int edmonds_karp(int n, int m, int s, int t, vector<vector<long long int>>& graph)
{
    vector<vector<long long int>> residual_graph(n+1, vector<long long int>(n+1, 0));
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            residual_graph[i][j]=graph[i][j];
        }
    }

    long long int max_flow=0;
    while(true)
    {
      vector<pair<pair<int,int>, long long int>> augmenting_path;
      BFS(n, s, t, residual_graph, augmenting_path);

      if(augmenting_path.size()==0) break;

      long long int min_weight=1;
      max_flow+=min_weight;

      int total_edges_on_path= augmenting_path.size();
      for(int i=0; i<=total_edges_on_path-2; i++)
      {
        int v=augmenting_path[i].first.second;
        for(int j=1; j<=n; j++)
        {
            residual_graph[j][v]=0;
            residual_graph[v][j]=0;
        }
      }
    }
    return max_flow;
}



int main()
{
    int n, m; // n = number of nodes, m = number of directed edges
    cin>>n>>m;
    int s=1, t=n;// s = source, t = sink

    vector<vector<long long int>> graph(n+1, vector<long long int>(n+1, 0));//stores the capacity of the (u,v) edge, actually is an adjacency matrix

    for(int i=1; i<=m; i++)
    {
        int u, v;
        long long int w=1;
        cin>>u>>v;
        graph[u][v]+=w;
    }

    cout<<edmonds_karp(n, m, s, t, graph)<<endl;
    return 0;
}
