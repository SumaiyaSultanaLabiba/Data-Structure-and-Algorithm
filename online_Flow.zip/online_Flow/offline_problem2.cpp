#include<iostream>
#include<bits/stdc++.h>
using namespace std;


// BFS for finding augmenting path
void BFS(int n, int s, int t, vector<vector<int>>& residual_graph, vector<pair<pair<int,int>,int>>& augmenting_path)
{
    queue<int> q;
    vector<bool> visited(n, false);
    vector<int> parent(n, -1);

    q.push(s);
    visited[s]=true;

    while(!q.empty())
    {
        int current=q.front();
        q.pop();
        for(int v=0; v<n; v++)
        {
            if(residual_graph[current][v]>0 && !visited[v])
            {
                parent[v]=current;
                visited[v]=true;
                q.push(v);
            }
        }
    }

    if(!visited[t]) return;
    int u=parent[t];
    int v=t;
    while(u!=-1)
    {
        augmenting_path.push_back({{u,v}, residual_graph[u][v]});
        v=u;
        u=parent[v];
    }
}


// Edmonds-Karp algorithm
void edmonds_karp(int n, int m, int s, int t, vector<vector<int>>& graph)
{
    vector<vector<int>> residual_graph(n, vector<int>(n, 0));
    vector<vector<int>> flow(n, vector<int>(n, 0));
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            residual_graph[i][j]=graph[i][j];
        }
    }

    int max_flow=0;
    while(true)
    {
      vector<pair<pair<int,int>,int>> augmenting_path;
      BFS(n, s, t, residual_graph, augmenting_path);

      if(augmenting_path.size()==0) break;

      int min_weight=INT_MAX;
      for(pair<pair<int,int>, int> p: augmenting_path)
      {
        if(p.second<min_weight) min_weight=p.second;
      }

      max_flow+=min_weight;
      for(pair<pair<int,int>,int> p: augmenting_path)
      {
        int u=p.first.first;
        int v=p.first.second;
        residual_graph[u][v]-=min_weight;
        flow[u][v]+=min_weight;
        residual_graph[v][u]+=min_weight;
      }
    }
    cout<<max_flow<<endl;
    for(int u=0; u<n; u++)
    {
        for(int v=0; v<n; v++)
        {
            if(u==n-2 || v==n-1) continue;
            if(flow[u][v]>0)
            {
                cout<<u<<" "<<v<<endl;
            }
        }
    }
}



int main()
{
    int N, K, M; // n = number of staffs, k= number of presiding officers, m = number of compatibility entries
    cin>>N>>K>>M;

    int n = N+2; // n = number of nodes
    int m = M+N; // m= number of edges
    vector<vector<int>> graph(n, vector<int>(n, 0));//stores the capacity of the (u,v) edge, actually is an adjacency matrix


    // connecting the source 'N' to first K nodes, that is ID 0 to K-1
    for(int i=0; i<=K-1; i++)
    {
        graph[N][i]=1;
    }

    // compatibility entries
    for(int i=0; i<M; i++)
    {
        int u, v;
        int w=1;
        cin>>u>>v;
        graph[u][v]=w;
    }

    // connecting last (N-K) nodes, that is ID K to N-1, to the sink node 'N+1'
    for(int i=K; i<=N-1; i++)
    {
        graph[i][N+1]=1;
    }

    int s, t;// s = source, t = sink
    s=N, t=N+1;

    edmonds_karp(n, m, s, t, graph);
    return 0;
}
