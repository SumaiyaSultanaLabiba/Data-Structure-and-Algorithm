#include<iostream>
#include<bits/stdc++.h>
using namespace std;


void BFS(int n, int s, int t, vector<vector<long long int>>& residual_graph, vector<pair<pair<int,int>, long long int>>& augmenting_path)
{
    queue<int> q;
    vector<bool> visited(n+1, false);
    vector<int> parent(n+1, -1);

    q.push(s);
    visited[s]=true;

    while(!q.empty())
    {
        int current=q.front();
        q.pop();
        for(int v=1; v<=n; v++)
        {
            if(residual_graph[current][v]>0 && !visited[v])
            {
                parent[v]=current;
                visited[v]=true;
                q.push(v);
            }
        }
    }

    if(!visited[t]) return;
    int u=parent[t];
    int v=t;
    while(u!=-1)
    {
        augmenting_path.push_back({{u,v}, residual_graph[u][v]});
        v=u;
        u=parent[v];
    }
}



long long int edmonds_karp(int n, int s, int t, vector<vector<long long int>>& graph)
{
    vector<vector<long long int>> residual_graph(n+1, vector<long long int>(n+1, 0));
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            residual_graph[i][j]=graph[i][j];
        }
    }

    long long int max_flow=0;
    while(true)
    {
      vector<pair<pair<int,int>, long long int>> augmenting_path;
      BFS(n, s, t, residual_graph, augmenting_path);

      if(augmenting_path.size()==0) break;

      long long int min_weight=INT_MAX;
      for(pair<pair<int,int>, long long int> p: augmenting_path)
      {
        if(p.second<min_weight) min_weight=p.second;
      }

      max_flow+=min_weight;
      for(pair<pair<int,int>, long long int> p: augmenting_path)
      {
        int u=p.first.first;
        int v=p.first.second;
        residual_graph[u][v]-=min_weight;
        residual_graph[v][u]+=min_weight;
      }
    }
    return max_flow;
}



int main()
{
    int num_of_testcases=0;
    cin>>num_of_testcases;

    for(int count=1; count<=num_of_testcases; count++)
    {
    int M, H;
    cin>>M>>H;
    float R;
    cin>>R;
    
    vector<pair<int,int>> mouse(M+1, {0, 0});
    for(int i=1; i<=M; i++)
    {
        int x=0, y=0;
        cin>>x>>y;
        mouse[i]={x,y};
    }

    vector<pair<pair<int,int>,int>> hole(H+1, {{0,0},0});
    for(int i=1; i<=H; i++)
    {
        int x=0, y=0, capacity=0;
        cin>>x>>y>>capacity;
        hole[i]={{x,y}, capacity};
    }


    int V; // V = number of nodes, E = number of edges
    V=M+H+2;
    int s=1, t=V;// s = source, t = sink

    vector<vector<long long int>> graph(V+1, vector<long long int>(V+1, 0));//stores the capacity of the (u,v) edge, actually is an adjacency matrix

    for(int m=1; m<=M; m++)
    {
        graph[s][m+1]=1;
        for(int h=1; h<=H; h++)
        {
           int x1, x2, y1, y2;
           x1=mouse[m].first;
           y1=mouse[m].second;
           x2=hole[h].first.first;
           y2=hole[h].first.second;

           float distance=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
           if(distance<=R)
           {
            graph[m+1][h+M+1]=1;
           }
        }
    }

    for(int h=1; h<=H; h++)
    {
        graph[h+M+1][t]=hole[h].second;
    }

    cout<<"Case "<<count<<": "<<edmonds_karp(V, s, t, graph)<<endl;
    }
    return 0;
}

/*
5
3 2 5.0
0 0
2 2
4 4
0 0 2
5 5 2
4 2 3.0
1 1
2 2
3 3
4 4
2 2 2
3 3 1
2 2 1.0
0 0
10 10
3 3 1
12 12 1
3 3 2.5
0 0
2 0
4 0
1 0 1
3 0 1
5 0 1
5 2 5.0
1 1
1 2
1 3
1 4
1 5
0 0 2
2 2 2
*/