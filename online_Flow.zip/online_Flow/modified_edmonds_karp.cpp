//this is the modified version of regular edmonds-karp algorithm
// here we consider a graph with bidirectional, antiparallel edges
// here we do not distinguish between forward edge and back edge

#include<iostream>
#include<bits/stdc++.h>
using namespace std;


void BFS(int n, int s, int t, vector<vector<int>> residual_graph, vector<pair<pair<int,int>, int>>& augmenting_path)
{
    queue<int> q;
    vector<bool> visited(n+1, false);
    vector<int> parent(n+1, -1);

    q.push(s);
    visited[s]=true;

    while(!q.empty())
    {
        int current=q.front();
        q.pop();
        for(int i=1; i<=n; i++)
        {
            if(residual_graph[current][i]>0 && visited[i]==false)
            {
                parent[i]=current;
                visited[i]=true;
                q.push(i);
            }
        }
    }

    if(!visited[t]) return;
    int u=parent[t];
    int v=t;
    while(u!=-1)
    {
        augmenting_path.push_back({{u,v}, residual_graph[u][v]});
        v=u;
        u=parent[v];
    }
}



int edmonds_karp(int n, int m, int s, int t, vector<vector<int>>& graph)
{
    vector<vector<int>> residual_graph(n+1, vector<int>(n+1, 0));
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            residual_graph[i][j]=graph[i][j];
        }
    }

    int max_flow=0;
    while(true)
    {
      vector<pair<pair<int,int>, int>> augmenting_path;
      BFS(n, s, t, residual_graph, augmenting_path);

      if(augmenting_path.size()==0) break;

      int min_weight=INT_MAX;
      for(pair<pair<int,int>, int> p: augmenting_path)
      {
        if(p.second<min_weight) min_weight=p.second;
      }

      for(pair<pair<int,int>, int> p: augmenting_path)
      {
        int u=p.first.first;
        int v=p.first.second;
        residual_graph[u][v]-=min_weight;
        residual_graph[v][u]+=min_weight;
      }
      max_flow+=min_weight;
    }

    return max_flow;
}



int main()
{
    int T;
    cin>>T;
    for(int count=1; count<=T; count++)
    {
    int n; // n = number of nodes, m = number of directed edges
    cin>>n;
    int s, t;// s = source, t = sink
    cin>>s>>t;
    int m;
    cin>>m;

    vector<vector<int>> graph(n+1, vector<int>(n+1, 0));//stores the capacity of the (u,v) edge, actually is an adjacency matrix

    for(int i=1; i<=m; i++)
    {
        int u, v, w;
        cin>>u>>v>>w;
        graph[u][v]+=w;
        graph[v][u]+=w;
    }

    cout<<"Case "<<count<<": "<<edmonds_karp(n, m, s, t, graph)<<endl;
    }
    return 0;
}



