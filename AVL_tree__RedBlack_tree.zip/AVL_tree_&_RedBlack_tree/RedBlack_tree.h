#include<iostream>
#include<queue>
using namespace std;

template<typename KEY, typename VALUE>
class Node
{
    public:
    KEY key;
    VALUE value;
    Node<KEY,VALUE>* left;
    Node<KEY,VALUE>* right;
    Node<KEY,VALUE>* parent;
    string colour;

    public:
    Node(KEY k, VALUE v)
    {
        this->key=k;
        this->value=v;
        this->left=nullptr;
        this->right=nullptr;
        this->parent=nullptr;
        this->colour="red";
    }

    Node* rotateLeft()
    {
        Node<KEY,VALUE>* B=this;
        Node<KEY,VALUE>* X=this->left;
        Node<KEY,VALUE>* A=this->right;
        Node<KEY,VALUE>* Y=this->right->left;
        Node<KEY,VALUE>* Z=this->right->right;

        A->left=B;
        A->parent=B->parent;
        if(B->parent)
        {
            if(B->parent->left==B) B->parent->left=A;
            else B->parent->right=A;
        }
        B->parent=A;
        B->right=Y;
        if(Y) Y->parent=B;

        return A;
    }


    Node* rotateRight()
    {
        Node<KEY,VALUE>* A=this;
        Node<KEY,VALUE>* B=this->left;
        Node<KEY,VALUE>* Z=this->right;
        Node<KEY,VALUE>* X=this->left->left;
        Node<KEY,VALUE>* Y=this->left->right;

        B->right=A;
        B->parent=A->parent;

        if(A->parent)
        {
            if(A->parent->left==A) A->parent->left=B;
            else A->parent->right=B;
        }

        A->parent=B;
        A->left=Y;
        if(Y) Y->parent=A;

        return B;
    }
};



template<typename KEY, typename VALUE>
class RedBlack_tree
{
    private:
    Node<KEY,VALUE>* tree_root;

    public:
    RedBlack_tree()
    {
        this->tree_root=nullptr;
    }


    private:
    static void destructor(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return;
        destructor(root->left);
        destructor(root->right);
        delete root;
    }


    static Node<KEY,VALUE>* insert_helper(Node<KEY,VALUE>* root, KEY key, VALUE value)
    {
        if(root==nullptr) 
        {
            root= new Node<KEY,VALUE>(key, value);
            return root;
        }

        if(key<root->key)
        {
            root->left=insert_helper(root->left, key, value);
            root->left->parent=root;
        }
        else if(key>root->key)
        {
            root->right=insert_helper(root->right, key, value);
            root->right->parent=root;
        }
        else return root; // duplicates are rejected

        if(root->parent==nullptr)
        {
            root->colour="black";
            return root;
        }

        if(root->parent && root->parent->colour=="black")
        {
            return root;
        }

        Node<KEY,VALUE>* parent= root->parent;
        Node<KEY,VALUE>* grandparent= parent->parent;
        Node<KEY,VALUE>* uncle= (grandparent->left==parent)? grandparent->right:grandparent->left;

        if(uncle!=nullptr && uncle->colour=="red")
        {
            parent->colour="black";
            uncle->colour="black";
            grandparent->colour="red";
            return grandparent;
        }
        else
        {
            //RR
            if(grandparent->right==parent && parent->right==root)
            {
                parent->colour = "black"; 
                grandparent->colour = "red";
                return grandparent->rotateLeft();
            }
            //RL
            else if(grandparent->right==parent && parent->left==root)
            {
                parent->colour = "black"; 
                grandparent->colour = "red";
                parent->rotateRight();
                return grandparent->rotateLeft();
            }
            //LL
            else if(grandparent->left==parent && parent->left==root)
            {
                parent->colour = "black"; 
                grandparent->colour = "red";
                return grandparent->rotateRight();
            }
            //LR
            else 
            {
                parent->colour = "black"; 
                grandparent->colour = "red";
                parent->rotateLeft();
                return grandparent->rotateRight();
            }
        }
    }

    static Node<KEY,VALUE>* find_successor(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return root;
        Node<KEY,VALUE>* current=root;
        while(current->left) current=current->left;
        return current;
    }


    static Node<KEY,VALUE>* fix_double_black(Node<KEY,VALUE>* child, Node<KEY,VALUE>* parent, bool is_left)
    {
        if(!parent) return child;

        Node<KEY,VALUE>* sibling= (is_left)? parent->right : parent->left;
        
        if(sibling && sibling->colour=="red")
        {
            parent->colour="red";
            sibling->colour="black";

            if(is_left) parent= parent->rotateLeft();
            else parent= parent->rotateRight();

            sibling= (is_left)? parent->right : parent->left;
        }

        bool sibling_left_red= (sibling && sibling->left && sibling->left->colour=="red");
        bool sibling_right_red= (sibling && sibling->right && sibling->right->colour=="red");

        if(!sibling_left_red && !sibling_right_red)
        {
            if(sibling) sibling->colour="red";
            if(parent->colour=="red") parent->colour="black";
            else
            {
                if(parent->parent)
                {
                    bool parent_is_left= (parent->parent->left==parent);
                    return fix_double_black(parent, parent->parent, parent_is_left);
                }
            }
            return parent;
        }

        if(is_left)
        {
            if(!sibling_right_red)
            {
                if(sibling->left) sibling->left->colour="black";
                sibling->colour="red";
                sibling= sibling->rotateRight();
                parent->right= sibling;
                sibling->parent= parent;
            }
            sibling->colour= parent->colour;
            parent->colour= "black";
            if(sibling->right) sibling->right->colour= "black";
            return parent->rotateLeft();
        }
        else
        {
            if(!sibling_left_red)
            {
                if(sibling->right) sibling->right->colour="black";
                sibling->colour="red";
                sibling= sibling->rotateLeft();
                parent->left= sibling;
                sibling->parent= parent;
            }
            sibling->colour= parent->colour;
            parent->colour= "black";
            if(sibling->left) sibling->left->colour= "black";
            return parent->rotateRight();
        }
    }

    static Node<KEY,VALUE>* remove_helper(Node<KEY,VALUE>* root, KEY key)
    {
        if(root==nullptr) return root;

        if(root->key>key)
        {
            root->left= remove_helper(root->left, key);
            if(root->left) root->left->parent= root;
        }

        else if(root->key<key)
        {
            root->right= remove_helper(root->right, key);
            if(root->right) root->right->parent= root;
        }

        else
        {
            if(root->left && root->right)
            {
                Node<KEY,VALUE>* successor= find_successor(root->right);
                root->key= successor->key;
                root->value= successor->value;
                root->right= remove_helper(root->right, successor->key);
                if(root->right) root->right->parent= root;
            }

            else
            {
                Node<KEY,VALUE>* child= (root->left)? root->left: root->right;
                Node<KEY,VALUE>* parent= root->parent;
                bool is_left_child= (parent && parent->left==root);
                bool deleted_black= (root->colour=="black");
                bool child_black= (!child || child->colour=="black");

                if(child) child->parent= parent;
                if(parent)
                {
                    if(is_left_child) parent->left= child;
                    else parent->right= child;
                }
                delete root;

                if(deleted_black)
                {
                    if(child && child->colour=="red") child->colour= "black";
                    else
                    {
                        child= fix_double_black(child, parent, is_left_child);
                    }
                }
                return child;
            }
        }
        return root;
    }


    static bool search_helper(Node<KEY,VALUE>* root, KEY key)
    {
        if(root==nullptr) return false;
        if(root->key==key) return true;
        else if(root->key>key) return search_helper(root->left, key);
        else return search_helper(root->right, key);
    }

    int priority_less_helper(Node<KEY,VALUE>* root, KEY key)
    {
        if(root==nullptr) return 0;
        int result=0;
        if(key>root->key) result++;
        result+=priority_less_helper(root->left, key);
        result+=priority_less_helper(root->right, key);
        return result;
    }

    static string inorder_helper(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return "";
        string result="";
        result+=inorder_helper(root->left);
        result+=to_string(root->key)+"  ";
        result+=inorder_helper(root->right);
        return result;
    }

    static string preorder_helper(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return "";
        string result="";
        result+=to_string(root->key)+"  ";
        result+=preorder_helper(root->left);
        result+=preorder_helper(root->right);
        return result;
    }

    static string postorder_helper(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return "";
        string result="";
        result+=postorder_helper(root->left);
        result+=postorder_helper(root->right);
        result+=to_string(root->key)+"  ";
        return result;
    }

    static string levelorder_helper(Node<KEY,VALUE>* root)
    {
        string result="";
        Node<KEY,VALUE>* current= root;
        queue<Node<KEY,VALUE>*> q;
        q.push(current);
        while(!q.empty())
        {
            Node<KEY,VALUE>* top=q.front();
            result+=to_string(top->key)+" ";
            q.pop();
            if(top->left) q.push(top->left);
            if(top->right) q.push(top->right);
        }
        return result;
    }



    public:
    ~RedBlack_tree()
    {
        destructor(this->tree_root);
    }

    bool insert(KEY key, VALUE value)
    {
        if(this->search(key)) return false;
        this->tree_root= insert_helper(this->tree_root, key, value);
        return true;
    }

    bool remove(KEY key)
    {
        if(!this->search(key)) return false;
        this->tree_root= remove_helper(this->tree_root, key);
        return true;
    }

    bool search(KEY key)
    {
        bool is_found= search_helper(this->tree_root, key);
        return is_found;
    }

    int priority_less(KEY key)
    {
        return priority_less_helper(this->tree_root, key);
    }

    string inorder()
    {
        return inorder_helper(this->tree_root);
    }

    string preorder()
    {
        return preorder_helper(this->tree_root);
    }

    string postorder()
    {
        return postorder_helper(this->tree_root);
    }

    string levelorder()
    {
        return levelorder_helper(this->tree_root);
    }
};
