#include<iostream>
#include<fstream>
#include "RedBlack_tree.h"
using namespace std;



int main() {
    ifstream fin("input_problem1.txt");
    ofstream fout("output_problem1.txt");
    if(!fin.is_open() || !fout.is_open())
    {
        cerr<<"File not opened"<<endl;
        return 1;
    }

    RedBlack_tree<int,int> tree;

    int N=0;
    fin>>N;

    fout<<N<<endl;
    for(int count=0; count<N; count++)
    {
        int e=0, x=0;
        fin>>e>>x;

        if(e==0)
        {
            if(tree.remove(x)) fout<<e<<" "<<x<<" "<<1<<endl;
            else fout<<e<<" "<<x<<" "<<0<<endl;
        }
        else if(e==1)
        {
            if(tree.insert(x,x)) fout<<e<<" "<<x<<" "<<1<<endl;
            else fout<<e<<" "<<x<<" "<<0<<endl;
        }
        else if(e==2)
        {
            if(tree.search(x)) fout<<e<<" "<<x<<" "<<1<<endl;
            else fout<<e<<" "<<x<<" "<<0<<endl;
        }
        else if(e==3)
        {
            fout<<e<<" "<<x<<" "<<tree.priority_less(x)<<endl;
        }
    }
    fin.close();
    fout.close();
    return 0;
}