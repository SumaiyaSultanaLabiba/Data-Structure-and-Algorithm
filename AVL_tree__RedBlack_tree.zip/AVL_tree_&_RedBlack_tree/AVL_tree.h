#include<iostream>
#include<queue>
using namespace std;

template<typename KEY, typename VALUE>
class Node
{
    public:
    KEY key;
    VALUE value;
    Node<KEY,VALUE>* left;
    Node<KEY,VALUE>* right;
    int height;

    public:
    Node(KEY k, VALUE v)
    {
        this->key=k;
        this->value=v;
        this->left=nullptr;
        this->right=nullptr;
        this->height=1;
    }

    static int getHeight(Node<KEY,VALUE>* node)
    {
        if(node==nullptr) return 0;
        return node->height;
    }

    void updateHeight()
    {
        this->height= max(getHeight(this->left), getHeight(this->right))+1;
    }

    int getBalance()
    {
        return (getHeight(this->left)- getHeight(this->right));
    }


    Node* rotateLeft()
    {
        Node<KEY,VALUE>* B=this;
        Node<KEY,VALUE>* X=this->left;
        Node<KEY,VALUE>* A=this->right;
        Node<KEY,VALUE>* Y=this->right->left;
        Node<KEY,VALUE>* Z=this->right->right;

        A->left=B;
        B->right=Y;

        B->updateHeight();
        A->updateHeight();

        return A;
    }


    Node* rotateRight()
    {
        Node<KEY,VALUE>* A=this;
        Node<KEY,VALUE>* B=this->left;
        Node<KEY,VALUE>* Z=this->right;
        Node<KEY,VALUE>* X=this->left->left;
        Node<KEY,VALUE>* Y=this->left->right;

        B->right=A;
        A->left=Y;

        A->updateHeight();
        B->updateHeight();

        return B;
    }
};


template<typename KEY, typename VALUE>
class AVL_tree
{
    private:
    Node<KEY,VALUE>* tree_root;

    public:
    AVL_tree()
    {
        this->tree_root=nullptr;
    }

    private:
    static void destructor(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return;
        destructor(root->left);
        destructor(root->right);
        delete root;
    }

    static Node<KEY,VALUE>* insert_helper(Node<KEY,VALUE>* root, KEY key, VALUE value)
    {
        if(root==nullptr) return new Node<KEY,VALUE>(key, value);
        if(key<root->key) root->left=insert_helper(root->left, key, value);
        else if(key>root->key) root->right=insert_helper(root->right, key, value);
        else return root;

        root->updateHeight();
        int balance=root->getBalance();

        //right heavy
        if(balance<-1)
        {
        if(key>root->right->key)
        {
            return root->rotateLeft();
        }
        else
        {
            root->right=root->right->rotateRight();
            return root->rotateLeft();
        }
        }


        //left heavy
        else if(balance>1)
        {
        if(key<root->left->key)
        {
            return root->rotateRight();
        }
        else
        {
            root->left=root->left->rotateLeft();
            return root->rotateRight();
        }
        }
        else return root;
    }

    static Node<KEY,VALUE>* find_successor(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return root;
        Node<KEY,VALUE>* current=root;
        while(current->left) current=current->left;
        return current;
    }

    static Node<KEY,VALUE>* remove_helper(Node<KEY,VALUE>* root, KEY key)
    {
        if(root==nullptr) return root;
        if(key<root->key) root->left=remove_helper(root->left, key);
        else if(key>root->key) root->right=remove_helper(root->right, key);
        else
        {
            if(!root->left && !root->right) 
            {
                delete root;
                root=nullptr;
            }
            else if(root->left && !root->right) 
            {
                Node<KEY,VALUE>* temp=root->left;
                delete root;
                root=nullptr;
                return temp;
            }
            else if(!root->left && root->right) 
            {
                Node<KEY,VALUE>* temp=root->right;
                delete root;
                root=nullptr;
                return temp;
            }
            else
            {
                Node<KEY,VALUE>* successor=find_successor(root->right);
                root->key=successor->key;
                root->value=successor->value;
                root->right=remove_helper(root->right, successor->key);
            }
        }

        if(root==nullptr) return root;

        root->updateHeight();
        int balance= root->getBalance();

        //right heavy
        if(balance<-1)
        {
        if(root->right->getBalance()<=0)
        {
            return root->rotateLeft();
        }
        else
        {
            root->right=root->right->rotateRight();
            return root->rotateLeft();
        }
        }

        //left heavy
        else if(balance>1)
        {
        if(root->left->getBalance()>=0)
        {
            return root->rotateRight();
        }
        else
        {
            root->left=root->left->rotateLeft();
            return root->rotateRight();
        }
        }
        else return root;
    }

    static bool search_helper(Node<KEY,VALUE>* root, KEY key)
    {
        if(root==nullptr) return false;
        if(root->key==key) return true;
        else if(root->key>key) return search_helper(root->left, key);
        else return search_helper(root->right, key);
    }

    static string inorder_helper(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return "";
        string result="";
        result+=inorder_helper(root->left);
        result+=to_string(root->key)+"  ";
        result+=inorder_helper(root->right);
        return result;
    }

    static string preorder_helper(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return "";
        string result="";
        result+=to_string(root->key)+"  ";
        result+=preorder_helper(root->left);
        result+=preorder_helper(root->right);
        return result;
    }

    static string postorder_helper(Node<KEY,VALUE>* root)
    {
        if(root==nullptr) return "";
        string result="";
        result+=postorder_helper(root->left);
        result+=postorder_helper(root->right);
        result+=to_string(root->key)+"  ";
        return result;
    }

    static string levelorder_helper(Node<KEY,VALUE>* root)
    {
        string result="";
        Node<KEY,VALUE>* current= root;
        queue<Node<KEY,VALUE>*> q;
        q.push(current);
        while(!q.empty())
        {
            Node<KEY,VALUE>* top=q.front();
            result+=to_string(top->key)+" ";
            q.pop();
            if(top->left) q.push(top->left);
            if(top->right) q.push(top->right);
        }
        return result;
    }

    public:
    ~AVL_tree()
    {
        destructor(this->tree_root);
    }

    bool insert(KEY key, VALUE value)
    {
        if(this->search(key)) return false;
        this->tree_root= insert_helper(this->tree_root, key, value);
        return true;
    }

    bool remove(KEY key)
    {
        if(!this->search(key)) return false;
        this->tree_root= remove_helper(this->tree_root, key);
        return true;
    }

    bool search(KEY key)
    {
        bool is_found= search_helper(this->tree_root, key);
        return is_found;
    }

    string inorder()
    {
        return inorder_helper(this->tree_root);
    }

    string preorder()
    {
        return preorder_helper(this->tree_root);
    }

    string postorder()
    {
        return postorder_helper(this->tree_root);
    }

    string levelorder()
    {
        return levelorder_helper(this->tree_root);
    }
};

