#include<iostream>
#include<fstream>
#include "AVL_tree.h"
using namespace std;


int main()
{
    ifstream fin("input_problem2.txt");
    ofstream fout("output_problem2.txt");
    if(!fin.is_open() || !fout.is_open())
    {
        cerr<<"File not opened"<<endl;
        return 1;
    }

    AVL_tree<int,int> tree;

    int N=0;
    fin>>N;

    fout<<N<<endl;
    for(int count=0; count<N; count++)
    {
        int e=0, x=0;
        fin>>e>>x;

        if(e==0)
        {
            if(tree.remove(x)) fout<<e<<" "<<x<<" "<<1<<endl;
            else fout<<e<<" "<<x<<" "<<0<<endl;
        }
        else if(e==1)
        {
            if(tree.insert(x,x)) fout<<e<<" "<<x<<" "<<1<<endl;
            else fout<<e<<" "<<x<<" "<<0<<endl;
        }
        else if(e==2)
        {
            if(x==1) fout<<tree.preorder()<<endl;
            else if(x==2) fout<<tree.inorder()<<endl;
            else if(x==3) fout<<tree.postorder()<<endl;
            else if(x==4) fout<<tree.levelorder()<<endl;
            else ;
        }
        else;
    }
    fin.close();
    fout.close();
    return 0;
}