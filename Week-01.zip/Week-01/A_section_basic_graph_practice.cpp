#include<iostream>
#include<bits/stdc++.h>
using namespace std;

int max(int a, int b, int c, int d)
{
    int first=(a>b)? a:b;
    int second=(c>d)? c:d;
    return (first>second)? first: second;
}



void BFS(vector<vector<int>>& result, vector<vector<int>>& grid, vector<vector<pair<int, int>>>& graph, vector<pair<int, int>>& start)
{
    /**/
}




int main()
{
    int n, m;
    cin>>n>>m;

    //input grid
    vector<vector<int>> grid(n, vector<int>(m));
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            cin>>grid[i][j];
        }
    }

    //build graph
    vector<vector<pair<int, int>>> graph(n*m);
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            if(grid[i][j]==1) continue;

            //left move possible??
            if(j>0 && grid[i][j-1]==0 && grid[i][j-1]==2 && grid[i][j-1]==3) graph[i*n+m].push_back({i, j-1});

            //right move possible??
            if(j<m-1 && grid[i][j+1]==0 && grid[i][j+1]==2 && grid[i][j+1]==3) graph[i*n+m].push_back({i, j+1});

            //up move possible??
            if(i>0 && grid[i-1][j]==0 && grid[i-1][j]==2 && grid[i-1][j]==3) graph[i*n+m].push_back({i-1, j});

            //down move possible??
            if(i<n-1 && grid[i+1][j]==0 && grid[i+1][j]==2 && grid[i+1][j]==3) graph[i*n+m].push_back({i+1, j});
        }
    }


    //storing the positions of fire, obstacle, free, and me
    vector<pair<int, int>> fire;
    vector<pair<int, int>> obstacle;
    vector<pair<int, int>> free;
    vector<pair<int, int>> me;

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            if(grid[i][j]==2) fire.push_back({i,j}); 
            else if(grid[i][j]==1) obstacle.push_back({i,j});
            else if(grid[i][j]==0) free.push_back({i,j});
            else if(grid[i][j]==3) me.push_back({i,j});
        }
    }

    //detrmining minimum time for me to reach any cell
    vector<vector<int>> min_me(n, vector<int>(m));
    BFS(min_me, grid, graph, me);

    
    //determining minimum time for fire to reach any cell
    int number_of_fireSource=fire.size();
    vector<vector<int>> min_fire(n, vector<int>(m));
    for(int i=0; i<number_of_fireSource; i++)
    {
        BFS(min_fire, grid, graph, fire);
    }
    

    return 0;
}