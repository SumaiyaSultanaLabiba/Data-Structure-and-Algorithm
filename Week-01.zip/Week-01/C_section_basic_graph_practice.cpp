#include<iostream>
#include<vector>
#include<queue>
using namespace std;


int main()
{
    int n, m; //n= number of nodes, m=number of edges
    cin>>n>>m;
    vector<vector<int>> adjList(n+1);
    vector<int> indegree(n+1, 0);
    for(int i=0; i<m; i++)
    {
        int u, v;
        cin>>u>>v;
        adjList[u].push_back(v);
        indegree[v]++;
    }

    queue<int> q_enter;
    queue<int> q_exit;
    
    for(int i=1; i<=n; i++)
    {
       if(indegree[i]==0) {q_enter.push(i); indegree[i]=-1;}
    }

    
        while(!q_enter.empty())
        {
            int current=q_enter.front();
            q_enter.pop();
            q_exit.push(current);
            for(int j=0; j<adjList[current].size(); j++)
            {
                indegree[adjList[current][j]]--;
            }
            for(int i=1; i<=n; i++)
            {
            if(indegree[i]==0) {q_enter.push(i); indegree[i]=-1;}
            }
        }
    

    int count=q_exit.size();
    if(count<n) {cout<<-1<<endl; return 0;}
    
    for(int i=0; i<count; i++)
    {
        cout<<q_exit.front()<<"  ";
        q_exit.pop();
    }
    
    return 0;
}