#include <bits/stdc++.h>
using namespace std;


void dfs(int root, vector<vector<int>>& adjList, vector<int> visited)
{
    visited[root]=true;
    for(int i=0; i<adjList[root].size(); i++)
    {
        if(visited[adjList[root][i]]==false)
        {
            dfs(adjList[root][i], adjList, visited);
        }
    }
}

int main()
{
    int n=0, m=0;
    cin>>n>>m;
    int total_nodes=(n-2)*(m-2);
    vector<vector<int>> adjList(total_nodes+1);

    vector<vector<int>> grid(n, vector<int>(m));

    for(int i=0; i<=n-1; i++)
    {
        for(int j=0; j<=m-1; j++)
        {
           cin>>grid[i][j];
        }
    }
    
    int id_tracker=1;
    for(int i=1; i<=n-2; i++)
    {
        for(int j=1; j<=m-2; j++)
        {
            int current=grid[i][j];
            int left=grid[i][j-1];
            int right=grid[i][j+1];
            int up=grid[i-1][j];
            int down=grid[i+1][j];

            if(current==0 && left==0) adjList[id_tracker].push_back(id_tracker-1);
            if(current==0 && right==0) adjList[id_tracker].push_back(id_tracker+1);
            if(current==0 && up==0) adjList[id_tracker].push_back(id_tracker-m);
            if(current==0 && down==0) adjList[id_tracker].push_back(id_tracker+m);

            id_tracker++;
        }
    }

    vector<int> visited(total_nodes+1, false);
    int room=0;
 
    for(int id=1; id<=total_nodes; id++)
    {
        if(!visited[id] && grid[id/(m-2)][id%(m-2)]==0)
        {
            dfs(id, adjList, visited);
            room++;
        }
    }
    cout<<room;
    return 0;
}